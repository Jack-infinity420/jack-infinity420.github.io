# -*- coding: utf-8 -*-
import pandas as pd, numpy as np
S = pd.read_csv(r"D:\流量分析实战\261112\Encrypted_Mobile_Social_Media\_work\gead\budget_sweep.csv")
out = []
for split in ["iid", "ood"]:
    for b in [30, 100, 300, 1000]:
        row = {"split": split, "budget": b}
        for m in ["DT(hard)", "RT(IID)", "RT(GEAD)"]:
            s = S[(S.model == m) & (S.split == split)].sort_values("n_rules")
            if b < s.n_rules.min() or b > s.n_rules.max():
                row[m + "_posC"] = np.nan; row[m + "_negR"] = np.nan; continue
            x = np.log10(s.n_rules.values)
            row[m + "_posC"] = round(float(np.interp(np.log10(b), x, s.pos_consistency.values)), 3)
            row[m + "_negR"] = round(float(np.interp(np.log10(b), x, s.neg_credibility.values)), 3)
        out.append(row)
print(pd.DataFrame(out).to_string(index=False))
# also the raw grid
print()
print(S.pivot_table(index=["md","ms"], columns=["model","split"],
                    values=["n_rules","pos_consistency"]).round(3).to_string())
