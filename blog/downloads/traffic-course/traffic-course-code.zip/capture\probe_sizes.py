# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "_work"))
import numpy as np, pandas as pd
from common import load, APPS
df = load(verbose=False)
print("=== min_ps 最常见的 15 个取值 ===")
print(df.bidirectional_min_ps.value_counts().head(15).to_string())
print("\n=== max_ps 最常见的 15 个取值 ===")
print(df.bidirectional_max_ps.value_counts().head(15).to_string())
print("\n=== min_ps 出现在 40/54/60/66/74 的比例 ===")
for v in [40, 46, 54, 60, 66, 74, 78, 94, 98]:
    n = int((df.bidirectional_min_ps == v).sum())
    if n: print(f"  {v:4d}: {n:6d} ({n/len(df)*100:5.2f}%)")
print("\n=== 按协议/端口看 60 与 54 ===")
for v in [54, 60]:
    s = df[df.bidirectional_min_ps == v]
    print(f"min_ps=={v}: n={len(s)}, protocol={s.protocol.value_counts().to_dict()}, "
          f"dst_port top={s.dst_port.value_counts().head(4).to_dict()}")
print("\n=== 每个 App 的 min_ps 众数 ===")
print(df.groupby("label").bidirectional_min_ps.agg(lambda s: s.value_counts().head(3).to_dict()).to_string())
print("\n=== packets==2 的流里，min/max 组合 ===")
s = df[df.bidirectional_packets == 2]
print(s.groupby(["bidirectional_min_ps", "bidirectional_max_ps"]).size().nlargest(8).to_string())
