# -*- coding: utf-8 -*-
"""Shared loader / feature engineering / evaluation helpers."""
import os, json, hashlib
import numpy as np, pandas as pd

BASE = r"D:\流量分析实战\261112\Encrypted_Mobile_Social_Media"
WORK = os.path.join(BASE, "_work")
APPS = ["facebook","instagram","linkedin","reddit","snapchat","telegram","tiktok","twitter","whatsapp","youtube"]

# ---------------- leaks / ids that must never become features ----------------
ID_COLS = ["id","expiration_id","Label","capture_file","_file",
           "bidirectional_first_seen_ms","bidirectional_last_seen_ms",
           "src2dst_first_seen_ms","src2dst_last_seen_ms",
           "dst2src_first_seen_ms","dst2src_last_seen_ms"]
# DPI oracle (NFStream/ nDPI output) -> leakage reference view only
DPI_COLS = ["application_name","application_category_name","application_is_guessed",
            "application_confidence"]

LAN_PORTS = {1900,5353,5355,3702,67,68,137,138,139,5350,8610,8612,57621,17500,52217}

def _hashcat(s, n=64):
    return s.map(lambda v: "x" if pd.isna(v) else hashlib.md5(str(v).encode()).hexdigest()[:6])

def load(verbose=True):
    df = pd.concat([pd.read_csv(os.path.join(BASE, a + ".csv"), low_memory=False).assign(_file=a)
                    for a in APPS], ignore_index=True)
    df = df.rename(columns={"Label": "label"})
    if verbose:
        print("loaded", df.shape)

    # ---- background / label-noise flag ----
    import ipaddress
    def pub(ip):
        try: return ipaddress.ip_address(str(ip)).is_global
        except Exception: return False
    df["dst_public"] = df["dst_ip"].map(pub)
    df["is_lan_bg"] = (~df["dst_public"]) | df["dst_port"].isin(LAN_PORTS)

    # ---- interpretable derived features ----
    eps = 1e-9
    df["dur_ms"] = df["bidirectional_duration_ms"]
    df["pkt"]     = df["bidirectional_packets"]
    df["byt"]     = df["bidirectional_bytes"]
    df["up_byt"]  = df["src2dst_bytes"]; df["dn_byt"] = df["dst2src_bytes"]
    df["dn_ratio"] = df["dn_byt"] / (df["byt"] + eps)
    df["dn_pkt_ratio"] = df["dst2src_packets"] / (df["pkt"] + eps)
    df["pps"] = df["pkt"] / (df["dur_ms"]/1000.0 + eps)
    df["bps"] = df["byt"] / (df["dur_ms"]/1000.0 + eps)
    df["bytes_per_pkt"] = df["byt"] / (df["pkt"] + eps)
    df["ps_mean"]  = df["bidirectional_mean_ps"]
    df["ps_std"]   = df["bidirectional_stddev_ps"]
    df["ps_max"]   = df["bidirectional_max_ps"]
    df["piat_mean"]= df["bidirectional_mean_piat_ms"]
    df["piat_std"] = df["bidirectional_stddev_piat_ms"]
    df["is_instant"] = (df["dur_ms"] <= 0).astype(int)
    df["is_udp"] = (df["protocol"] == 17).astype(int)
    df["is_tcp"] = (df["protocol"] == 6).astype(int)
    df["flags_total"] = (df["bidirectional_syn_packets"] + df["bidirectional_ack_packets"] +
                         df["bidirectional_psh_packets"] + df["bidirectional_rst_packets"] +
                         df["bidirectional_fin_packets"])
    df["syn_ratio"] = df["bidirectional_syn_packets"] / (df["pkt"] + eps)
    df["psh_ratio"] = df["bidirectional_psh_packets"] / (df["pkt"] + eps)
    df["rst_cnt"]   = df["bidirectional_rst_packets"]
    df["fin_cnt"]   = df["bidirectional_fin_packets"]
    df["has_sni"]   = df["requested_server_name"].notna().astype(int)
    df["sni_len"]   = df["requested_server_name"].fillna("").str.len()
    df["has_ja4"]   = df["client_fingerprint"].notna().astype(int)
    df["has_srvfp"] = df["server_fingerprint"].notna().astype(int)
    df["is_quic"]   = ((df["protocol"] == 17) & (df["dst_port"] == 443)).astype(int)
    df["is_tls"]    = ((df["protocol"] == 6)  & (df["dst_port"] == 443)).astype(int)
    df["dst_port_is_443"] = (df["dst_port"] == 443).astype(int)
    df["dst_port_is_53"]  = (df["dst_port"] == 53).astype(int)
    df["dst_port_ephem"]  = (df["dst_port"] >= 1024).astype(int)
    df["dst_port_lt1024"] = ((df["dst_port"] > 0) & (df["dst_port"] < 1024)).astype(int)
    return df

# ---------------- feature views ----------------
PS_STATS = [f"{d}_{s}_ps" for d in ("bidirectional","src2dst","dst2src")
            for s in ("min","mean","stddev","max")]
PIAT_STATS = [f"{d}_{s}_piat_ms" for d in ("bidirectional","src2dst","dst2src")
              for s in ("min","mean","stddev","max")]
FLAG_COLS = [f"{d}_{f}_packets" for d in ("bidirectional","src2dst","dst2src")
             for f in ("syn","ack","psh","rst","fin","cwr","ece","urg")]

CORE_VOLUME = ["bidirectional_duration_ms","bidirectional_packets","bidirectional_bytes",
               "src2dst_packets","src2dst_bytes","dst2src_packets","dst2src_bytes",
               "bidirectional_duration_ms","src2dst_duration_ms","dst2src_duration_ms"]
DERIVED = ["dn_ratio","dn_pkt_ratio","pps","bps","bytes_per_pkt"]
FLAG_DERIVED = ["is_udp","is_tcp","flags_total","syn_ratio","psh_ratio","rst_cnt","fin_cnt"]

# V1: 纯统计（无 L4 身份、无明文元数据）—— 最严格"加密载荷"视图
V1 = list(dict.fromkeys(CORE_VOLUME + PS_STATS + PIAT_STATS + DERIVED + FLAG_DERIVED))
# V2: + 传输层身份（协议号 / 端口）
V2 = V1 + ["protocol","dst_port","src_port","ip_version","dst_port_is_443",
           "dst_port_is_53","dst_port_ephem","dst_port_lt1024","is_quic","is_tls"]
# V3: + TLS/QUIC 元数据（指纹存在性、JA4、服务端指纹），不含 SNI 明文
V3 = V2 + ["has_sni","sni_len","has_ja4","has_srvfp"]
# V4: + SNI 明文 + 设备 OUI（取证现场可见的最强合法视图）
V4 = V3 + ["src_oui","dst_oui"]
# V5: DPI oracle（泄漏参照，仅用于量化"如果直接用 DPI 会有多高"）
V5 = V4 + DPI_COLS

VIEWS = {"V1_flow_stats": V1, "V2_l4_identity": V2, "V3_tls_meta": V3,
         "V4_sni_oui": V4, "V5_dpi_oracle": V5}

CAT_MAP = {"src_oui":"src_oui_c","dst_oui":"dst_oui_c",
           "application_name":"dpi_app_c","application_category_name":"dpi_cat_c"}

def build_matrix(df, cols, cat_levels=None, fit=True):
    """Return numeric float32 matrix + column names; one-hot / hash-encode categoricals."""
    cat_levels = cat_levels or {}
    out, names = [], []
    for c in cols:
        if c in ("src_oui","dst_oui"):
            key = CAT_MAP[c]
            s = df[c].astype(str)
            if fit:
                cat_levels[key] = sorted(s.unique().tolist())
            m = pd.get_dummies(s, prefix=c, dtype=np.float32)
            out.append(m); names += m.columns.tolist()
        elif c in ("application_name","application_category_name"):
            key = CAT_MAP[c]
            s = df[c].astype(str)
            if fit:
                cat_levels[key] = sorted(s.unique().tolist())
            m = pd.get_dummies(s, prefix="dpi", dtype=np.float32)
            out.append(m); names += m.columns.tolist()
        elif c in ("requested_server_name","client_fingerprint","server_fingerprint"):
            s = _hashcat(df[c]).astype(str)
            key = "h_"+c
            if fit:
                cat_levels[key] = sorted(s.unique().tolist())
            m = pd.get_dummies(s, prefix=c[:6], dtype=np.float32)
            out.append(m); names += m.columns.tolist()
        else:
            x = pd.to_numeric(df[c], errors="coerce").astype(np.float64)
            x = x.replace([np.inf,-np.inf], np.nan)
            if c in ("byt","up_byt","dn_byt","dur_ms","pkt","bps","pps",
                     "bidirectional_duration_ms","bidirectional_bytes",
                     "src2dst_bytes","dst2src_bytes","src2dst_packets","dst2src_packets",
                     "src2dst_duration_ms","dst2src_duration_ms") and c in cols:
                pass
            out.append(x.rename(c).to_frame()); names.append(c)
    X = pd.concat(out, axis=1) if out else pd.DataFrame(index=df.index)
    X = X.fillna(0.0).astype(np.float32)
    return X, names, cat_levels

def metrics(y_true, y_pred, labels=APPS):
    from sklearn.metrics import accuracy_score, f1_score, balanced_accuracy_score
    return dict(acc=accuracy_score(y_true, y_pred),
                macro_f1=f1_score(y_true, y_pred, average="macro", labels=labels, zero_division=0),
                bal_acc=balanced_accuracy_score(y_true, y_pred))

def per_class_recall(y_true, y_pred, labels=APPS):
    from sklearn.metrics import confusion_matrix
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    rec = cm.diagonal() / np.maximum(cm.sum(1), 1)
    return pd.Series(rec, index=labels), cm
