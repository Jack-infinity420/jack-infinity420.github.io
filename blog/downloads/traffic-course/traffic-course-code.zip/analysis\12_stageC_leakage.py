# -*- coding: utf-8 -*-
"""Stage C: leakage / shortcut audit + permutation importance."""
import os, sys, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np, pandas as pd
from common import *
pd.set_option("display.width", 250)

from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.model_selection import GroupKFold, cross_val_predict, StratifiedKFold
from sklearn.inspection import permutation_importance
from sklearn.metrics import accuracy_score, f1_score, balanced_accuracy_score

df = load()
mask = ((~df.is_lan_bg) & (df.dst_port != 53)).values
d = df[mask].reset_index(drop=True); y = d["label"].values
print("subset APP_NDNS", len(d))

# --- OUI purity ---
for c in ["src_oui","dst_oui"]:
    g = d.groupby(c)["label"].agg(n="size", purity=lambda x: x.value_counts(normalize=True).iloc[0])
    print(f"\n{c}: {len(g)} levels, weighted purity={ (g.purity*g.n).sum()/g.n.sum():.4f}")
    print(g.sort_values("n",ascending=False).head(6).round(3).to_string())

print("\n=== flows per OUI across labels (is OUI label-specific?) ===")
ct = pd.crosstab(d.src_oui, d.label)
top = ct.sum(1).nlargest(8).index
print(ct.loc[top].to_string())

F_V1 = ["bidirectional_duration_ms","bidirectional_packets","bidirectional_bytes",
        "src2dst_packets","src2dst_bytes","dst2src_packets","dst2src_bytes",
        "bidirectional_mean_ps","bidirectional_stddev_ps","bidirectional_max_ps",
        "bidirectional_mean_piat_ms","bidirectional_stddev_piat_ms",
        "bytes_per_pkt","dn_ratio","dn_pkt_ratio","pps","bps",
        "is_udp","is_tcp","syn_ratio","psh_ratio","rst_cnt","fin_cnt"]
F_V2 = F_V1 + ["protocol","dst_port","src_port","ip_version"]
F_V3 = F_V2 + ["has_sni","sni_len","has_ja4","has_srvfp"]
combos = {"V1":F_V1, "V2":F_V2, "V3":F_V3,
          "V3+src_oui":F_V3+["src_oui"], "V3+dst_oui":F_V3+["dst_oui"],
          "V3+both_oui":F_V3+["src_oui","dst_oui"]}

rows=[]
model = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.08, max_leaf_nodes=31, random_state=0)
print("\n=== IID(StratifiedKFold) vs DEVICE-HELDOUT(GroupKFold by src_mac) vs DAY-HELDOUT(GroupKFold by capture_day) ===")
for tag, cols in combos.items():
    X,_,_ = build_matrix(d, cols); X = X.values
    for proto, cv in [("iid", StratifiedKFold(5, shuffle=True, random_state=42)),
                      ("mac", GroupKFold(5))]:
        groups = None if proto=="iid" else d.src_mac.values
        pred = cross_val_predict(model, X, y, cv=cv, groups=groups, n_jobs=1)
        m = dict(view=tag, protocol=proto, n=len(y), n_feat=X.shape[1],
                 acc=accuracy_score(y,pred),
                 macro_f1=f1_score(y,pred,average="macro",labels=APPS,zero_division=0),
                 bal_acc=balanced_accuracy_score(y,pred))
        rows.append(m); print(f"  {tag:12s} {proto:4s} acc={m['acc']:.4f} f1={m['macro_f1']:.4f} bal={m['bal_acc']:.4f}")
res = pd.DataFrame(rows); res.to_csv(os.path.join(WORK,"results_C_leakage.csv"), index=False, encoding="utf-8-sig")
print("\n", res.pivot_table(index="view", columns="protocol", values="acc").round(4).to_string())

# --- permutation importance on V1 (pure stats) ---
print("\n=== permutation importance (V1 flow stats, HGB, IID holdout) ===")
from sklearn.model_selection import train_test_split
X,names,_ = build_matrix(d, F_V1); X=X.values
Xtr,Xte,ytr,yte = train_test_split(X,y,test_size=0.3,stratif=...,random_state=0) if False else train_test_split(X,y,test_size=0.3,stratify=y,random_state=0)
mdl = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.08, max_leaf_nodes=31, random_state=0).fit(Xtr,ytr)
pi = permutation_importance(mdl, Xte, yte, n_repeats=10, random_state=0, scoring="balanced_accuracy", n_jobs=-1)
imp = pd.DataFrame({"feature":names,"imp":pi.importances_mean,"std":pi.importances_std}).sort_values("imp",ascending=False)
print(imp.head(20).round(4).to_string(index=False))
imp.to_csv(os.path.join(WORK,"perm_importance_V1.csv"), index=False, encoding="utf-8-sig")
print("baseline bal_acc:", round(balanced_accuracy_score(yte, mdl.predict(Xte)),4))
