﻿# -*- coding: utf-8 -*-
"""Stage E: human-readable rule set on true labels, background-noise rules,
expert checks (paper's Insight 3), confusion matrices, figures."""
import os, sys, json, warnings
warnings.filterwarnings("ignore")
os.environ.setdefault("JOBLIB_TEMP_FOLDER", r"C:\Windows\Temp")
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np, pandas as pd
from common import *
import gead as G

from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.metrics import confusion_matrix, accuracy_score, f1_score, balanced_accuracy_score
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = os.path.join(WORK, "gead"); os.makedirs(OUT, exist_ok=True)
RULE_FEATS = ["dur_ms","pkt","byt","dn_ratio","dn_pkt_ratio","bytes_per_pkt","pps","bps",
              "ps_mean","ps_std","ps_max","piat_mean","piat_std",
              "is_udp","syn_ratio","psh_ratio","rst_cnt","fin_cnt",
              "dst_port","has_sni","has_ja4","is_instant"]
CN = {"dur_ms":"流持续时长(ms)","pkt":"包数","byt":"字节数","dn_ratio":"下行字节占比",
      "dn_pkt_ratio":"下行包占比","bytes_per_pkt":"平均包长(B)","pps":"包速率(包/s)",
      "bps":"字节率(B/s)","ps_mean":"包长均值","ps_std":"包长标准差","ps_max":"最大包长",
      "piat_mean":"包间隔均值(ms)","piat_std":"包间隔标准差","is_udp":"是否UDP",
      "syn_ratio":"SYN占比","psh_ratio":"PSH占比","rst_cnt":"RST数","fin_cnt":"FIN数",
      "dst_port":"目的端口","has_sni":"有SNI","has_ja4":"有JA4指纹","is_instant":"瞬时流(时长=0)"}

df = load()

# ======================================================================= 1. 背景噪声规则
print("="*70); print("1. 背景流量识别（标签噪声定位）")
bg = df.is_lan_bg
print(df[bg].groupby("dst_port").size().nlargest(12).to_string())
print("\nprivate/multicast dst share:", round((~df.dst_public).mean(),4))
print(pd.crosstab(df.label, df.is_lan_bg, normalize="index").round(3).to_string())

# ======================================================================= 2. 专家核查
print("\n"+"="*70); print("2. 专家核查（论文 Insight 3：特征/标签/模型）")
d_app = df[(~df.is_lan_bg) & (df.dst_port != 53)].reset_index(drop=True)
print("\n[2a] 单包流占比（twitter 异常）")
per = df.groupby("label").apply(lambda x: pd.Series({
    "flows": len(x),
    "单包流占比": (x.bidirectional_packets <= 1).mean(),
    "单包流占比(仅APP)": (x[(~x.is_lan_bg)&(x.dst_port!=53)].bidirectional_packets <= 1).mean(),
    "无SNI占比(仅APP)": x[(~x.is_lan_bg)&(x.dst_port!=53)].requested_server_name.isna().mean(),
    "mac数": x.src_mac.nunique()}), include_groups=False)
print(per.round(3).to_string())

print("\n[2b] 同一 SNI 跨 App 的复用（共享基础设施）")
s = d_app[d_app.requested_server_name.notna()]
g = s.groupby("requested_server_name")["label"].agg(cnt="size", nu="nunique",
        purity=lambda x: x.value_counts(normalize=True).iloc[0])
print(g.sort_values("cnt",ascending=False).head(12).round(3).to_string())
print("SNI 加权纯度: %.3f | 覆盖流占比: %.3f" %
      ((g.purity*g.cnt).sum()/g.cnt.sum(), len(s)/len(d_app)))

print("\n[2c] JA4 指纹：OS 共享 vs 应用私有")
c = d_app[d_app.client_fingerprint.notna()]
gg = c.groupby("client_fingerprint")["label"].agg(cnt="size", nu="nunique",
        purity=lambda x: x.value_counts(normalize=True).iloc[0])
print(gg.sort_values("cnt",ascending=False).head(10).round(3).to_string())
print("JA4 加权纯度: %.3f" % ((gg.purity*gg.cnt).sum()/gg.cnt.sum()))

print("\n[2d] 上行/下行结构（按 App 中位数，仅 APP 子集）")
print(d_app.groupby("label")[["pkt","byt","dn_ratio","bytes_per_pkt","dur_ms",
      "ps_mean","piat_mean","syn_ratio","psh_ratio","rst_cnt"]].median().round(2).to_string())

# ======================================================================= 3. 人类可读规则集 C
print("\n"+"="*70); print("3. 规则集 C：直接可读决策树（真标签）")
X = d_app[RULE_FEATS].replace([np.inf,-np.inf], np.nan).fillna(0).values.astype(np.float64)
y = d_app.label.values
day = d_app.capture_day.values
rng = np.random.default_rng(0)
iid_idx = np.where(day != "day5")[0]; rng.shuffle(iid_idx)
cut = int(0.75*len(iid_idx)); tr, te = iid_idx[:cut], iid_idx[cut:]
ood = np.where(day=="day5")[0]

for depth, mleaf in [(4,80),(5,50),(6,30)]:
    t = DecisionTreeClassifier(max_depth=depth, min_samples_leaf=mleaf, random_state=0).fit(X[tr], y[tr])
    print(f"  depth={depth} leaf>={mleaf}: leaves={t.get_n_leaves():3d} "
          f"iid_acc={accuracy_score(y[te],t.predict(X[te])):.3f} "
          f"ood_acc={accuracy_score(y[ood],t.predict(X[ood])):.3f}")

t = DecisionTreeClassifier(max_depth=5, min_samples_leaf=50, random_state=0).fit(X[tr], y[tr])
yp = t.predict(X[tr])
rows=[]
for lid in np.unique(t.apply(X[tr])):
    m = t.apply(X[tr]) == lid
    cls = t.predict(X[tr][m][:1])[0]
    conds = G._dedup_path(G.leaf_path(t.tree_, int(lid)))
    cn = " 且 ".join(G._fmt(f, th, op, RULE_FEATS, X[tr], CN) for f,th,op in conds)
    rows.append(dict(cls=cls, support=int(m.sum()),
                     conf=float((yp[m]==cls).mean()), prec=float((y[tr][m]==cls).mean()),
                     n_cond=len(conds), rule_cn=f"若 {cn} 则判为 {cls}",
                     rule_en="IF " + " AND ".join(G._fmt_en(f,th,op,RULE_FEATS,X[tr]) for f,th,op in conds) + f" THEN {cls}"))
RC = pd.DataFrame(rows).sort_values(["cls","support"], ascending=[True,False])
print(RC[["cls","support","prec","n_cond","rule_cn"]].to_string(index=False, max_colwidth=110))
RC.to_csv(os.path.join(OUT,"rules_tree_true_labels.csv"), index=False, encoding="utf-8-sig")
print("coverage:", RC.cls.nunique(), "/10 classes,", len(RC), "leaves")

# ======================================================================= 4. 混淆矩阵 + 图
print("\n"+"="*70); print("4. 图表")
from sklearn.ensemble import HistGradientBoostingClassifier
FULL = ["bidirectional_duration_ms","bidirectional_packets","bidirectional_bytes",
        "src2dst_packets","src2dst_bytes","dst2src_packets","dst2src_bytes",
        "ps_mean","ps_std","ps_max","piat_mean","piat_std","bytes_per_pkt","dn_ratio",
        "dn_pkt_ratio","pps","bps","is_udp","is_tcp","syn_ratio","psh_ratio","rst_cnt","fin_cnt"]
Xf = d_app[FULL].replace([np.inf,-np.inf],np.nan).fillna(0).values
hg = HistGradientBoostingClassifier(max_iter=400, learning_rate=0.08, max_leaf_nodes=31,
                                    random_state=0).fit(Xf[tr], y[tr])
cm = confusion_matrix(y[ood], hg.predict(Xf[ood]), labels=APPS)
cmn = cm / cm.sum(1, keepdims=True)
fig, ax = plt.subplots(figsize=(6.4,5.2), dpi=150)
im = ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
ax.set_xticks(range(10)); ax.set_xticklabels(APPS, rotation=45, ha="right", fontsize=8)
ax.set_yticks(range(10)); ax.set_yticklabels(APPS, fontsize=8)
for i in range(10):
    for j in range(10):
        v = cmn[i,j]
        if v > 0.01: ax.text(j, i, f"{v:.2f}", ha="center", va="center",
                             fontsize=6.5, color="white" if v>0.5 else "black")
ax.set_xlabel("predicted"); ax.set_ylabel("true app")
ax.set_title("HGB, V1 stats, OOD = Day-5 (row-normalised)")
fig.colorbar(im, fraction=0.046); fig.tight_layout()
fig.savefig(os.path.join(OUT,"cm_day5.png"))
print("saved cm_day5.png  OOD acc=%.3f bal=%.3f" %
      (accuracy_score(y[ood],hg.predict(Xf[ood])),
       balanced_accuracy_score(y[ood],hg.predict(Xf[ood]))))

# 会话级聚合：同一 (dst_ip, day) 内多流投票
pred_te = hg.predict(Xf[te])
sub = d_app.iloc[te].copy(); sub["pred"] = pred_te
key = ["dst_ip"]
vote = sub.groupby(key).agg(n=("pred","size"),
                            label=("label", lambda s: s.value_counts().index[0]),
                            pred=("pred", lambda s: s.value_counts().index[0]),
                            agree=("pred", lambda s: s.value_counts(normalize=True).iloc[0]))
vote = vote[vote.n >= 3]
print("多流聚合(dst_ip>=3流): units=%d acc=%.3f" % (len(vote), (vote.label==vote.pred).mean()))

json.dump({"ood_acc": float(accuracy_score(y[ood],hg.predict(Xf[ood]))),
           "ood_bal": float(balanced_accuracy_score(y[ood],hg.predict(Xf[ood]))),
           "ood_f1": float(f1_score(y[ood],hg.predict(Xf[ood]),average="macro",labels=APPS,zero_division=0)),
           "iid_acc": float(accuracy_score(y[te],hg.predict(Xf[te]))),
           "multi_flow_dstip_acc": float((vote.label==vote.pred).mean()),
           "multi_flow_units": int(len(vote))},
          open(os.path.join(OUT,"summary_numbers.json"),"w"), ensure_ascii=False, indent=2)
print("done")
