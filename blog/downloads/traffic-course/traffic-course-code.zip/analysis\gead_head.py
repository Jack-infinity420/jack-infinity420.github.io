# -*- coding: utf-8 -*-
"""GEAD (CCS'24) re-implementation for multi-class app fingerprinting.

Paper steps: ①root regression tree ②LC leaf identification ③LC augmentation
             ④subtree generation ⑤merge + discretization ⑥readable rules
"""
import numpy as np, pandas as pd
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier

# ---------------------------------------------------------------- NN access
class NNFunc:
    """Forward pass + gradient of a fitted sklearn MLPClassifier (via a pipeline
    StandardScaler). Gives us F(x) and dF/dx for GEAD Eq.(1)."""
    def __init__(self, pipe, classes):
        self.mu  = pipe[0].mean_.astype(np.float64)
        self.sd  = pipe[0].scale_.astype(np.float64)
        self.coefs = [w.astype(np.float64) for w in pipe[1].coefs_]
        self.bias  = [b.astype(np.float64) for b in pipe[1].intercepts_]
        self.classes = list(classes)
        self.n_layers = len(self.coefs)

    def forward(self, X, cache=False):
        a = (np.asarray(X, dtype=np.float64) - self.mu) / self.sd
        acts = [a]
        for i,(W,b) in enumerate(zip(self.coefs, self.bias)):
            z = a @ W + b
            if i < self.n_layers - 1:
                a = np.maximum(z, 0.0)
            else:
                z = z - z.max(1, keepdims=True)
                e = np.exp(z); a = e / e.sum(1, keepdims=True)
            acts.append(a)
        return (a, acts) if cache else a

    def grad_logit(self, X, cls_idx):
        """d p_c / d x_raw   (chain rule through the scaler)."""
        p, acts = self.forward(X, cache=True)
        g = np.zeros_like(p)
        g[:, cls_idx] = 1.0                     # d p_c / d p
        for i in range(self.n_layers - 1, -1, -1):
            if i == self.n_layers - 1:
                dz = p * (g - (g * p).sum(1, keepdims=True))   # softmax jacobian
            else:
                dz = g * (acts[i+1] > 0)
            g = dz @ self.coefs[i].T
        return g / self.sd                      # back to raw feature scale

    def prob(self, X, c):
        return self.forward(X)[:, self.classes.index(c)]

# ---------------------------------------------------------------- tree helpers
def all_leaf_paths(tree):
    """DFS once -> {leaf_id: [(feat_idx, threshold, '<='|'>'), ...]} root→leaf.
    Accepts either a fitted estimator or its `.tree_` object."""
    t = tree.tree_ if hasattr(tree, "tree_") else tree
    left, right, feat, thr = t.children_left, t.children_right, t.feature, t.threshold
    out = {}
    stack = [(0, [])]
    while stack:
        node, path = stack.pop()
        if left[node] == -1:
            out[int(node)] = path
            continue
        stack.append((int(left[node]),  path + [(int(feat[node]), float(thr[node]), "<=")]))
        stack.append((int(right[node]), path + [(int(feat[node]), float(thr[node]), ">")]))
    return out

def leaf_path(tree, leaf_id):
    return all_leaf_paths(tree).get(int(leaf_id), [])

def leaf_stats(reg, X, y):
    """Per-leaf: node id, n samples, mean, impurity(MSE), value."""
    leaf = reg.apply(X)
    out = []
    for lid in np.unique(leaf):
        m = leaf == lid
        yy = y[m]
        out.append(dict(leaf=int(lid), n=int(m.sum()), mean=float(yy.mean()),
                        mse=float(((yy - yy.mean())**2).mean()),
                        val=float(reg.tree_.value[lid].ravel()[0])))
    return pd.DataFrame(out)

# ---------------------------------------------------------------- merged tree
class MergedRT:
    """root tree per class + subtree replacing LC leaves."""
    def __init__(self, classes, n_classes):
        self.classes = list(classes); self.K = n_classes
        self.roots = {}      # c -> DecisionTreeRegressor
        self.subs  = {}      # c -> {leaf_id: DecisionTreeRegressor}
        self.lc    = {}      # c -> set(leaf ids)

    def fit_roots(self, X, P, md, ms):
        for j,c in enumerate(self.classes):
            r = DecisionTreeRegressor(max_depth=md, min_samples_leaf=ms, random_state=0)
            r.fit(X, P[:, j]); self.roots[c] = r
        return self

    def predict_proba(self, X):
        n = X.shape[0]; P = np.zeros((n, self.K))
        for j,c in enumerate(self.classes):
            r = self.roots[c]
            P[:, j] = r.predict(X)
            subs = self.subs.get(c)
            if subs:
                leaf = r.apply(X)
                for lid, st in subs.items():
                    m = leaf == lid
                    if m.any(): P[m, j] = st.predict(X[m])
        return P

    def predict(self, X):
        return np.array(self.classes)[self.predict_proba(X).argmax(1)]

    def n_rules(self):
        n = 0
        for c in self.classes:
            r = self.roots[c]
            base = int((r.tree_.children_left == -1).sum())
            for lid, st in self.subs.get(c, {}).items():
                base += int((st.tree_.children_left == -1).sum()) - 1
            n += base
        return n

# ---------------------------------------------------------------- GEAD
def gead(X, P, classes, nn, md=4, ms=60, alpha_O=0.9, alpha_E=0.9,
         beta=0.1, N=8, sub_md=3, sub_ms=20, ood_frac=0.5, seed=0,
         verbose=True, lc_min_n=30):
    """X: (n,d) features; P: (n,K) black-box probabilities; nn: NNFunc."""
    rng = np.random.default_rng(seed)
    M = MergedRT(classes, len(classes)).fit_roots(X, P, md, ms)
    lo, hi = np.nanmin(X, 0), np.nanmax(X, 0)
    span = np.where(hi > lo, hi - lo, 1.0)
    lo3, hi3 = lo - 0.05*span, hi + 0.05*span
    # keep the augmentation inside the feature's *semantic* domain
    nuniq = np.array([len(np.unique(X[:, k])) for k in range(X.shape[1])])
    is_bin = nuniq <= 2
    lo3 = np.where(is_bin, 0.0, np.maximum(lo3, 0.0 if (lo >= 0).all() else lo3))
    hi3 = np.where(is_bin, 1.0, hi3)
    nonneg = (lo >= 0)
    lo3 = np.where(nonneg, np.maximum(lo3, 0.0), lo3)
    total_lc = 0
    for j,c in enumerate(classes):
        r = M.roots[c]; y = P[:, j]
        st = leaf_stats(r, X, y)
        thrE = np.quantile(st.mse.values, alpha_E)
        thrO = np.quantile(st["mean"].values, alpha_O)
        lc = set(st[(st.mse >= thrE) | (st["mean"] >= thrO)]["leaf"].astype(int))
        lc |= set(st[st.n < lc_min_n]["leaf"].astype(int))   # poorly supported -> LC
        M.lc[c] = lc; total_lc += len(lc)
        assign = r.apply(X)
        M.subs[c] = {}
        for lid in lc:
            m = assign == lid
            if m.sum() < 5: continue
            Xl = X[m]
            path = leaf_path(r.tree_, lid)
            frozen = sorted({f for f,_,_ in path})
            free = [k for k in range(X.shape[1]) if k not in frozen]
            if not free: continue
            # ---- ③ LC augmentation (Eq.1 gradient steps + distribution resampling)
            Xg = Xl.copy()
            pts = [Xl.copy()]
            for it in range(N):
                g = nn.grad_logit(Xg, j)                       # dP_c/dx  (raw scale)
                cur = nn.forward(Xg)[:, j]
                # negative direction: push p_c down; positive direction: up (capped)
                neg = Xg - beta * g                            # descend
                pos = Xg + beta * g
                cap = cur < min(0.95, 2*P[:, j].mean() + 0.2)
                pos = np.where(cap[:, None], pos, Xg)
                Xg = np.where(rng.random(Xg.shape) < 0.5, neg, pos)
                Xg[:, free] = np.clip(Xg[:, free], lo3[free], hi3[free])
                Xg[:, frozen] = Xl[:, frozen]                  # keep path features fixed
                pts.append(Xg.copy())
            Xaug = np.vstack(pts)
            # distribution-guided exploration of the same subspace
            n_ood = int(ood_frac * len(Xaug))
            if n_ood > 0:
                Xo = Xl[rng.integers(0, len(Xl), n_ood)].copy()
                Xo[:, free] = rng.uniform(lo[free], hi[free], size=(n_ood, len(free)))
                Xaug = np.vstack([Xaug, Xo])
            db = np.asarray(is_bin, bool)[None, :]
            Xaug = np.where(db, (Xaug > 0.5).astype(float), Xaug)
            Xaug = np.clip(Xaug, np.where(nonneg, 0.0, -np.inf), np.inf)
            paug = nn.forward(Xaug)[:, j]
            # ---- ④ subtree
            sub = DecisionTreeRegressor(max_depth=sub_md, min_samples_leaf=sub_ms,
                                        random_state=0)
            sub.fit(Xaug, paug)
            M.subs[c][lid] = sub
        if verbose:
            print(f"  [GEAD] {c:10s} leaves={len(st):3d}  LC={len(lc):3d}  "
                  f"subtrees={len(M.subs[c]):3d}")
    if verbose: print(f"  [GEAD] total LC leaves = {total_lc}, rules = {M.n_rules()}")
    return M

