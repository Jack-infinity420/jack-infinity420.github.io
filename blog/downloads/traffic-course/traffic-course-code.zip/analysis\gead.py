# -*- coding: utf-8 -*-
"""GEAD (CCS'24) re-implementation for multi-class app fingerprinting.

Paper steps: ①root regression tree ②LC leaf identification ③LC augmentation
             ④subtree generation ⑤merge + discretization ⑥readable rules
"""
import numpy as np, pandas as pd
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier

# ---------------------------------------------------------------- NN access
class NNFunc:
    """Forward pass + gradient of a fitted sklearn MLPClassifier (via a pipeline
    StandardScaler). Gives us F(x) and dF/dx for GEAD Eq.(1)."""
    def __init__(self, pipe, classes):
        self.mu  = pipe[0].mean_.astype(np.float64)
        self.sd  = pipe[0].scale_.astype(np.float64)
        self.coefs = [w.astype(np.float64) for w in pipe[1].coefs_]
        self.bias  = [b.astype(np.float64) for b in pipe[1].intercepts_]
        self.classes = list(classes)
        self.n_layers = len(self.coefs)

    def forward(self, X, cache=False):
        a = (np.asarray(X, dtype=np.float64) - self.mu) / self.sd
        acts = [a]
        for i,(W,b) in enumerate(zip(self.coefs, self.bias)):
            z = a @ W + b
            if i < self.n_layers - 1:
                a = np.maximum(z, 0.0)
            else:
                z = z - z.max(1, keepdims=True)
                e = np.exp(z); a = e / e.sum(1, keepdims=True)
            acts.append(a)
        return (a, acts) if cache else a

    def grad_logit(self, X, cls_idx):
        """d p_c / d x_raw   (chain rule through the scaler)."""
        p, acts = self.forward(X, cache=True)
        g = np.zeros_like(p)
        g[:, cls_idx] = 1.0                     # d p_c / d p
        for i in range(self.n_layers - 1, -1, -1):
            if i == self.n_layers - 1:
                dz = p * (g - (g * p).sum(1, keepdims=True))   # softmax jacobian
            else:
                dz = g * (acts[i+1] > 0)
            g = dz @ self.coefs[i].T
        return g / self.sd                      # back to raw feature scale

    def prob(self, X, c):
        return self.forward(X)[:, self.classes.index(c)]

# ---------------------------------------------------------------- tree helpers
def all_leaf_paths(tree):
    """DFS once -> {leaf_id: [(feat_idx, threshold, '<='|'>'), ...]} root→leaf.
    Accepts either a fitted estimator or its `.tree_` object."""
    t = tree.tree_ if hasattr(tree, "tree_") else tree
    left, right, feat, thr = t.children_left, t.children_right, t.feature, t.threshold
    out = {}
    stack = [(0, [])]
    while stack:
        node, path = stack.pop()
        if left[node] == -1:
            out[int(node)] = path
            continue
        stack.append((int(left[node]),  path + [(int(feat[node]), float(thr[node]), "<=")]))
        stack.append((int(right[node]), path + [(int(feat[node]), float(thr[node]), ">")]))
    return out

def leaf_path(tree, leaf_id):
    return all_leaf_paths(tree).get(int(leaf_id), [])

def leaf_stats(reg, X, y):
    """Per-leaf: node id, n samples, mean, impurity(MSE), value."""
    leaf = reg.apply(X)
    out = []
    for lid in np.unique(leaf):
        m = leaf == lid
        yy = y[m]
        out.append(dict(leaf=int(lid), n=int(m.sum()), mean=float(yy.mean()),
                        mse=float(((yy - yy.mean())**2).mean()),
                        val=float(reg.tree_.value[lid].ravel()[0])))
    return pd.DataFrame(out)

# ---------------------------------------------------------------- merged tree
class MergedRT:
    """root tree per class + subtree replacing LC leaves."""
    def __init__(self, classes, n_classes):
        self.classes = list(classes); self.K = n_classes
        self.roots = {}      # c -> DecisionTreeRegressor
        self.subs  = {}      # c -> {leaf_id: DecisionTreeRegressor}
        self.lc    = {}      # c -> set(leaf ids)

    def fit_roots(self, X, P, md, ms):
        for j,c in enumerate(self.classes):
            r = DecisionTreeRegressor(max_depth=md, min_samples_leaf=ms, random_state=0)
            r.fit(X, P[:, j]); self.roots[c] = r
        return self

    def predict_proba(self, X):
        n = X.shape[0]; P = np.zeros((n, self.K))
        for j,c in enumerate(self.classes):
            r = self.roots[c]
            P[:, j] = r.predict(X)
            subs = self.subs.get(c)
            if subs:
                leaf = r.apply(X)
                for lid, st in subs.items():
                    m = leaf == lid
                    if m.any(): P[m, j] = st.predict(X[m])
        return P

    def predict(self, X):
        return np.array(self.classes)[self.predict_proba(X).argmax(1)]

    def n_rules(self):
        n = 0
        for c in self.classes:
            r = self.roots[c]
            base = int((r.tree_.children_left == -1).sum())
            for lid, st in self.subs.get(c, {}).items():
                base += int((st.tree_.children_left == -1).sum()) - 1
            n += base
        return n

# ---------------------------------------------------------------- GEAD
def gead(X, P, classes, nn, md=4, ms=60, alpha_O=0.9, alpha_E=0.9,
         beta=0.1, N=8, sub_md=3, sub_ms=20, ood_frac=0.5, seed=0,
         verbose=True, lc_min_n=30):
    """X: (n,d) features; P: (n,K) black-box probabilities; nn: NNFunc."""
    rng = np.random.default_rng(seed)
    M = MergedRT(classes, len(classes)).fit_roots(X, P, md, ms)
    lo, hi = np.nanmin(X, 0), np.nanmax(X, 0)
    span = np.where(hi > lo, hi - lo, 1.0)
    lo3, hi3 = lo - 0.05*span, hi + 0.05*span
    # keep the augmentation inside the feature's *semantic* domain
    nuniq = np.array([len(np.unique(X[:, k])) for k in range(X.shape[1])])
    is_bin = nuniq <= 2
    lo3 = np.where(is_bin, 0.0, np.maximum(lo3, 0.0 if (lo >= 0).all() else lo3))
    hi3 = np.where(is_bin, 1.0, hi3)
    nonneg = (lo >= 0)
    lo3 = np.where(nonneg, np.maximum(lo3, 0.0), lo3)
    total_lc = 0
    for j,c in enumerate(classes):
        r = M.roots[c]; y = P[:, j]
        st = leaf_stats(r, X, y)
        thrE = np.quantile(st.mse.values, alpha_E)
        thrO = np.quantile(st["mean"].values, alpha_O)
        lc = set(st[(st.mse >= thrE) | (st["mean"] >= thrO)]["leaf"].astype(int))
        lc |= set(st[st.n < lc_min_n]["leaf"].astype(int))   # poorly supported -> LC
        M.lc[c] = lc; total_lc += len(lc)
        assign = r.apply(X)
        M.subs[c] = {}
        for lid in lc:
            m = assign == lid
            if m.sum() < 5: continue
            Xl = X[m]
            path = leaf_path(r.tree_, lid)
            frozen = sorted({f for f,_,_ in path})
            free = [k for k in range(X.shape[1]) if k not in frozen]
            if not free: continue
            # ---- ③ LC augmentation (Eq.1 gradient steps + distribution resampling)
            Xg = Xl.copy()
            pts = [Xl.copy()]
            for it in range(N):
                g = nn.grad_logit(Xg, j)                       # dP_c/dx  (raw scale)
                cur = nn.forward(Xg)[:, j]
                # negative direction: push p_c down; positive direction: up (capped)
                neg = Xg - beta * g                            # descend
                pos = Xg + beta * g
                cap = cur < min(0.95, 2*P[:, j].mean() + 0.2)
                pos = np.where(cap[:, None], pos, Xg)
                Xg = np.where(rng.random(Xg.shape) < 0.5, neg, pos)
                Xg[:, free] = np.clip(Xg[:, free], lo3[free], hi3[free])
                Xg[:, frozen] = Xl[:, frozen]                  # keep path features fixed
                pts.append(Xg.copy())
            Xaug = np.vstack(pts)
            # distribution-guided exploration of the same subspace
            n_ood = int(ood_frac * len(Xaug))
            if n_ood > 0:
                Xo = Xl[rng.integers(0, len(Xl), n_ood)].copy()
                Xo[:, free] = rng.uniform(lo[free], hi[free], size=(n_ood, len(free)))
                Xaug = np.vstack([Xaug, Xo])
            db = np.asarray(is_bin, bool)[None, :]
            Xaug = np.where(db, (Xaug > 0.5).astype(float), Xaug)
            Xaug = np.clip(Xaug, np.where(nonneg, 0.0, -np.inf), np.inf)
            paug = nn.forward(Xaug)[:, j]
            # ---- ④ subtree
            sub = DecisionTreeRegressor(max_depth=sub_md, min_samples_leaf=sub_ms,
                                        random_state=0)
            sub.fit(Xaug, paug)
            M.subs[c][lid] = sub
        if verbose:
            print(f"  [GEAD] {c:10s} leaves={len(st):3d}  LC={len(lc):3d}  "
                  f"subtrees={len(M.subs[c]):3d}")
    if verbose: print(f"  [GEAD] total LC leaves = {total_lc}, rules = {M.n_rules()}")
    return M

# ---------------------------------------------------------------- rules
def _mask(X, conds):
    m = np.ones(len(X), bool)
    for f, thr, op in conds:
        m &= (X[:, f] <= thr) if op == "<=" else (X[:, f] > thr)
    return m

def _dedup_path(conds):
    seen, out = set(), []
    for f, thr, op in conds:
        if f in seen: continue
        seen.add(f); out.append((f, thr, op))
    return out

def _feat_kind(col):
    u = np.unique(col)
    if len(u) <= 2:                       return "bin"
    if np.allclose(u, np.round(u)):       return "int"
    return "cont"

def _norm(f, thr, op, X_ref):
    """Snap a split onto the feature's real domain (exact rewrite, no semantics change)."""
    col = X_ref[:, f]; kind = _feat_kind(col)
    if kind == "bin":
        return (">", 0.5) if op == ">" else ("<=", 0.5)
    if kind == "int":
        return (">=", float(np.ceil(thr))) if op == ">" else ("<=", float(np.floor(thr)))
    if abs(thr) < 1e-3 * (np.abs(col).max() + 1):
        return (">", 0.0) if op == ">" else ("<=", 0.0)
    return op, float(thr)

def _fmt(f, thr, op, names, X_ref, CN=None):
    CN = CN or {}
    nm = CN.get(names[f], names[f]); col = X_ref[:, f]; kind = _feat_kind(col)
    op2, thr2 = _norm(f, thr, op, X_ref)
    if kind == "bin":
        return f"{nm}={'1' if op2=='>' else '0'}"
    if kind == "int":
        return f"{nm} {op2} {int(thr2)}"
    q = int(round(100 * (col <= thr2).mean()))
    v = f"{thr2:.4g}"
    return f"{nm} {op2} {v} (p{q})"

def _fmt_en(f, thr, op, names, X_ref):
    nm = names[f]; col = X_ref[:, f]; kind = _feat_kind(col)
    op2, thr2 = _norm(f, thr, op, X_ref)
    if kind == "bin":   return f"{nm} == {1 if op2=='>' else 0}"
    if kind == "int":   return f"{nm} {op2} {int(thr2)}"
    return f"{nm} {op2} {thr2:.4g}"

def _prune(X, conds, base_sup, conf_fn, tol=0.02, min_frac=0.005):
    """Greedy condition removal + drop degenerate (near-empty) conditions."""
    keep = _dedup_path(conds)
    if not keep: return keep
    # a continuous condition that alone selects <min_frac of the corpus is an
    # augmentation artifact (e.g. a threshold pushed to 0 by the subtree)
    keep = [c for c in keep
            if _feat_kind(X[:, c[0]]) != "cont" or _mask(X, [c]).mean() >= min_frac] or keep
    c0 = conf_fn(_mask(X, keep))
    for i in range(len(keep)-1, -1, -1):
        if len(keep) <= 1: break
        trial = keep[:i] + keep[i+1:]
        m = _mask(X, trial)
        if m.sum() < base_sup: continue
        if conf_fn(m) >= c0 - tol:
            keep = trial
    return keep

def _rule_row(c, conds, X_ref, y_pred_ref, y_true_ref, feat_names, CN,
              extra=None):
    m = _mask(X_ref, conds)
    sup = int(m.sum())
    conf = float((y_pred_ref[m] == c).mean()) if y_pred_ref is not None else np.nan
    prec = float((y_true_ref[m] == c).mean()) if y_true_ref is not None else np.nan
    en = " AND ".join(_fmt_en(f, t, o, feat_names, X_ref) for f, t, o in conds)
    cn = " 且 ".join(_fmt(f, t, o, feat_names, X_ref, CN) for f, t, o in conds)
    row = dict(cls=c, support=sup, confidence=round(conf,3), precision_true=round(prec,3),
               n_cond=len(conds), rule_en=f"IF {en} THEN {c}",
               rule_cn=f"若 {cn} 则判为 {c}",
               conds=[(feat_names[f], o, round(t,6)) for f,t,o in conds])
    if extra: row.update(extra)
    return row

def extract_rules(M, feat_names, X_ref, y_pred_ref, y_true_ref, classes,
                  CN=None, min_support=20, min_conf=0.55, top_k=5,
                  max_conds=5, prune_tol=0.02, verbose=False):
    """Walk merged-tree leaves -> rule candidates -> prune conditions -> keep best."""
    CN = CN or {}
    rows, seen = [], set()
    for c in classes:
        r = M.roots[c]; la = r.apply(X_ref)
        for lid in sorted(M.lc.get(c, set())):
            st = M.subs[c].get(lid)
            if st is None: continue
            mroot = la == lid
            if mroot.sum() < 8: continue
            sl = st.apply(X_ref[mroot])
            for slid in np.unique(sl):
                m = mroot.copy(); m[mroot] = (sl == slid)
                if m.sum() < min_support: continue
                conds = _dedup_path(leaf_path(r.tree_, lid) + leaf_path(st.tree_, int(slid)))
                conds = conds[:max_conds]
                if _mask(X_ref, conds).sum() < min_support: continue
                conf0 = float((y_pred_ref[_mask(X_ref, conds)] == c).mean())
                if conf0 < min_conf: continue
                conds = _prune(X_ref, conds, min_support,
                               lambda mm: float((y_pred_ref[mm] == c).mean()), prune_tol)
                row = _rule_row(c, conds, X_ref, y_pred_ref, y_true_ref, feat_names, CN)
                if row["rule_en"] in seen: continue
                seen.add(row["rule_en"]); rows.append(row)
    R = pd.DataFrame(rows)
    if len(R) == 0: return R
    R = R.sort_values(["cls","support","confidence"], ascending=[True,False,False])
    return R.groupby("cls").head(top_k).reset_index(drop=True)

def perclass_rules(M, feat_names, X_ref, classes, priors, CN=None,
                   min_support=30, max_conds=5, top_k=2, tau_mult=2.0):
    """Per-class high-probability regions (the paper's per-attack rule lists).
    Fires on the class's distilled probability, so rare classes stay describable."""
    CN = CN or {}
    P = M.predict_proba(X_ref)
    rows, seen = [], set()
    for j, c in enumerate(classes):
        r = M.roots[c]; la = r.apply(X_ref); p = P[:, j]
        tau = max(0.30, tau_mult * priors.get(c, 0.1))
        cands = []
        lcset = M.lc.get(c, set())
        for lid in np.unique(la):
            m = la == lid
            if m.sum() < 8: continue
            if lid in lcset and lid in M.subs[c]:
                st = M.subs[c][lid]; sl = st.apply(X_ref[m])
                for slid in np.unique(sl):
                    conds = _dedup_path(leaf_path(r.tree_, int(lid)) +
                                        leaf_path(st.tree_, int(slid)))[:max_conds]
                    mm = _mask(X_ref, conds)
                    if mm.sum() < min_support: continue
                    cands.append((int(mm.sum()), float(p[mm].mean()), conds))
            else:
                conds = _dedup_path(leaf_path(r.tree_, int(lid)))[:max_conds]
                mm = _mask(X_ref, conds)
                if mm.sum() < min_support: continue
                cands.append((int(mm.sum()), float(p[mm].mean()), conds))
        cands.sort(key=lambda t: (-(t[0]*t[1])))
        kept = 0
        for sup, mp, conds in cands:
            if kept >= top_k: break
            if mp < tau: continue
            conds = _prune(X_ref, conds, min_support // 2,
                           lambda mm: float(p[mm].mean()), tol=0.05)
            mm = _mask(X_ref, conds)
            sup2, mp2 = int(mm.sum()), float(p[mm].mean())
            if sup2 < min_support // 2 or mp2 < tau: continue
            row = _rule_row(c, conds, X_ref, None, None, feat_names, CN,
                            extra=dict(mean_prob=round(mp2,3), prior=round(priors.get(c,0),3),
                                       lift=round(mp2/max(priors.get(c,1e-9),1e-9),2)))
            row["rule_cn"] = row["rule_cn"].replace("则判为", "则")
            if row["rule_en"] in seen: continue
            seen.add(row["rule_en"]); rows.append(row); kept += 1
    R = pd.DataFrame(rows)
    if len(R)==0: return R
    R = R.drop(columns=["confidence","precision_true"])
    return R.reset_index(drop=True)

# ---------------------------------------------------------------- fidelity
def fidelity(y_model, y_tree, labels):
    """Multi-class analogue of the paper's Positive Consistency / Negative Credibility."""
    pos, neg = [], []
    for c in labels:
        mc = y_model == c; tc = y_tree == c
        if mc.sum(): pos.append(float((y_tree[mc] == c).mean()))
        if tc.sum(): neg.append(float((y_model[tc] == c).mean()))
    return dict(pos_consistency=float(np.mean(pos)),
                neg_credibility=float(np.mean(neg)),
                agreement=float((y_model == y_tree).mean()))
