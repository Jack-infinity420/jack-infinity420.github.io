# -*- coding: utf-8 -*-
import os, json
import pandas as pd, numpy as np
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 200)

BASE = r"D:\流量分析实战\261112\Encrypted_Mobile_Social_Media"
APPS = ["facebook","instagram","linkedin","reddit","snapchat","telegram","tiktok","twitter","whatsapp","youtube"]
df = pd.concat([pd.read_csv(os.path.join(BASE,a+".csv"), low_memory=False).assign(_file=a) for a in APPS], ignore_index=True)

print("=== src_ip / dst_ip diversity ===")
print("n_src_ip", df.src_ip.nunique(), "n_dst_ip", df.dst_ip.nunique())
print(df.src_ip.value_counts().head(10).to_string())
print("\n=== src_mac ==="); print(df.src_mac.nunique()); print(df.src_mac.value_counts().head(6).to_string())

print("\n=== flows per app per day ===")
print(pd.crosstab(df._file, df.capture_day).to_string())

print("\n=== exact duplicate rows (all cols) ===", df.duplicated().sum())
print("=== duplicate on feature cols (excl id/ip/timestamps) ===")
key = ["src_port","dst_port","protocol","bidirectional_duration_ms","bidirectional_packets","bidirectional_bytes"]
print(df.duplicated(subset=key).sum())

print("\n=== sentinel / negative values in key stats ===")
numcols = [c for c in df.select_dtypes(include=[np.number]).columns]
for c in ["bidirectional_duration_ms","bidirectional_packets","bidirectional_bytes",
          "bidirectional_min_ps","bidirectional_mean_ps","bidirectional_stddev_ps","bidirectional_max_ps",
          "bidirectional_min_piat_ms","bidirectional_mean_piat_ms","src2dst_min_ps","dst2src_min_ps"]:
    s = df[c]
    print(f"{c:32s} min={s.min():>14.1f} p1={s.quantile(.01):>12.1f} med={s.median():>12.1f} p99={s.quantile(.99):>12.1f} max={s.max():>14.1f} n_neg={(s<0).sum():>6d} n_neg1={(s==-1).sum():>6d} n_inf={np.isinf(s).sum()}")

print("\n=== NaN counts (top 20) ===")
print(df.isna().sum().sort_values(ascending=False).head(20).to_string())

print("\n=== dst_port x Label (top ports) ===")
top = df.dst_port.value_counts().head(15).index
print(pd.crosstab(df.dst_port, df.Label).loc[top].to_string())

print("\n=== protocol x Label ===")
print(pd.crosstab(df.protocol, df.Label).to_string())

print("\n=== application_category_name x Label ===")
print(pd.crosstab(df.application_category_name, df.Label).to_string())

print("\n=== JA4 client fingerprint: coverage & purity ===")
c = df[df.client_fingerprint.notna()]
print("rows with JA4:", len(c), " distinct:", c.client_fingerprint.nunique())
g = c.groupby("client_fingerprint")["Label"].agg(["count", "nunique"])
print(g.sort_values("count", ascending=False).head(15).to_string())
print("\npurity of JA4 -> label (purity = max share):")
p = c.groupby("client_fingerprint")["Label"].apply(lambda s: s.value_counts(normalize=True).iloc[0])
print("weighted purity: %.4f" % ((p*g["count"]).sum()/g["count"].sum()))

print("\n=== SNI coverage & purity ===")
s = df[df.requested_server_name.notna()]
print("rows with SNI:", len(s))
p2 = s.groupby("requested_server_name")["Label"].apply(lambda x: x.value_counts(normalize=True).iloc[0])
cnt2 = s.groupby("requested_server_name")["Label"].size()
print("weighted purity: %.4f" % ((p2*cnt2).sum()/cnt2.sum()))
