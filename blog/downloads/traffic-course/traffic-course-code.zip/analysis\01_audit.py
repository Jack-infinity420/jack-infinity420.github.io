# -*- coding: utf-8 -*-
import os, sys, glob, json
import pandas as pd, numpy as np

BASE = r"D:\流量分析实战\261112\Encrypted_Mobile_Social_Media"
OUT  = os.path.join(BASE, "_work")
APPS = ["facebook","instagram","linkedin","reddit","snapchat","telegram","tiktok","twitter","whatsapp","youtube"]

frames=[]
for a in APPS:
    df = pd.read_csv(os.path.join(BASE, a+".csv"), low_memory=False)
    df["_file"] = a
    frames.append(df)
    print(f"{a:10s} shape={df.shape}")

df = pd.concat(frames, ignore_index=True)
print("\nTOTAL", df.shape)

# --- categorical / label columns profile ---
cat_cols = ["Label","application_name","application_category_name","application_is_guessed",
            "requested_server_name","client_fingerprint","server_fingerprint","user_agent",
            "content_type","capture_day","capture_file","protocol","src_port","dst_port",
            "src_oui","dst_oui","ip_version","splt_direction"]
for c in cat_cols:
    if c not in df.columns: 
        print("MISSING", c); continue
    s = df[c]
    nun = s.nunique(dropna=True)
    top = s.value_counts(dropna=False).head(4)
    print(f"\n== {c}  nunique={nun} dtype={s.dtype} nulls={s.isna().sum()}")
    for k,v in top.items():
        print(f"   {str(k)[:70]:70s} {v}")

print("\n\n===== Label vs file crosstab =====")
print(pd.crosstab(df["_file"], df["Label"].astype(str)).to_string())

print("\n===== application_name top 30 =====")
print(df["application_name"].astype(str).value_counts().head(30).to_string())

print("\n===== requested_server_name top 30 =====")
print(df["requested_server_name"].astype(str).value_counts().head(30).to_string())

# numeric availability
num = df.select_dtypes(include=[np.number])
print("\n===== numeric cols:", num.shape[1])
const = [c for c in num.columns if num[c].nunique(dropna=True)<=1]
print("constant numeric cols (%d):" % len(const), const)
