# -*- coding: utf-8 -*-
"""Stage B: (1) model families, (2) temporal Day-5 OOD, (3) multi-flow aggregation."""
import os, sys, json, time, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np, pandas as pd
from common import *

OUT = WORK
df = load()

from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import (RandomForestClassifier, ExtraTreesClassifier,
                              HistGradientBoostingClassifier)
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_predict

def make_models():
    return {
        "LogReg": make_pipeline(StandardScaler(), LogisticRegression(max_iter=1500, n_jobs=-1)),
        "DT":     DecisionTreeClassifier(max_depth=14, min_samples_leaf=20, random_state=0),
        "RF":     RandomForestClassifier(n_estimators=400, n_jobs=-1, random_state=0),
        "ET":     ExtraTreesClassifier(n_estimators=400, n_jobs=-1, random_state=0),
        "HGB":    HistGradientBoostingClassifier(max_iter=400, learning_rate=0.08,
                                                 max_leaf_nodes=31, random_state=0),
        "MLP":    make_pipeline(StandardScaler(),
                                MLPClassifier(hidden_layer_sizes=(256,128), max_iter=300,
                                              early_stopping=True, random_state=0)),
    }

# ---------------- multi-flow aggregation ----------------
AGGNUM = ["byt","pkt","dur_ms","ps_mean","ps_std","ps_max","piat_mean","piat_std",
          "dn_ratio","bytes_per_pkt","pps","bps","syn_ratio","psh_ratio"]
def aggregate(d, keys):
    g = d.groupby(keys, sort=False)
    base = g.agg(n_flows=("label","size"),
                 label=("label", lambda s: s.iloc[0]),
                 capture_day=("capture_day", lambda s: s.iloc[0]),
                 n_dst_ip=("dst_ip","nunique"), n_dst_port=("dst_port","nunique"),
                 sum_byt=("byt","sum"), sum_pkt=("pkt","sum"), sum_dur=("dur_ms","sum"),
                 ps_mean_m=("bidirectional_mean_ps","mean"),
                 ps_std_m=("bidirectional_stddev_ps","mean"),
                 ps_max_x=("bidirectional_max_ps","max"),
                 piat_mean_m=("bidirectional_mean_piat_ms","mean"),
                 piat_std_m=("bidirectional_stddev_piat_ms","mean"),
                 dn_ratio_m=("dn_ratio","mean"),
                 bpp_m=("bytes_per_pkt","mean"),
                 frac_udp=("is_udp","mean"), frac_tcp=("is_tcp","mean"),
                 frac_443=("dst_port_is_443","mean"), frac_53=("dst_port_is_53","mean"),
                 frac_lan=("is_lan_bg","mean"), frac_tls=("is_tls","mean"),
                 frac_quic=("is_quic","mean"), frac_sni=("has_sni","mean"),
                 frac_ja4=("has_ja4","mean"),
                 rst_sum=("rst_cnt","sum"), fin_sum=("fin_cnt","sum"))
    base["sum_byt"] = np.log1p(base["sum_byt"]); base["sum_pkt"] = np.log1p(base["sum_pkt"])
    base["sum_dur"] = np.log1p(base["sum_dur"])
    base["bps"] = base["sum_byt"]/ (base["sum_dur"]/1000.0 + 1e-9)
    base["pps"] = base["sum_pkt"]/ (base["sum_dur"]/1000.0 + 1e-9)
    for c in ["ps_mean_m","ps_std_m","ps_max_x","piat_mean_m","piat_std_m","dn_ratio_m",
              "bpp_m","pps","bps"]:
        base[c] = pd.to_numeric(base[c], errors="coerce").replace([np.inf,-np.inf], np.nan).fillna(0)
    base = base.reset_index()
    return base

AGG_COLS = ["n_flows","n_dst_ip","n_dst_port","sum_byt","sum_pkt","sum_dur",
            "ps_mean_m","ps_std_m","ps_max_x","piat_mean_m","piat_std_m","dn_ratio_m",
            "bpp_m","frac_udp","frac_tcp","frac_443","frac_53","frac_lan","frac_tls",
            "frac_quic","frac_sni","frac_ja4","rst_sum","fin_sum","pps","bps"]

# flow-level: log-transform heavy tails for the raw volume features
df["ps_mean"] = df["bidirectional_mean_ps"]; df["ps_std"] = df["bidirectional_stddev_ps"]
df["ps_max"]  = df["bidirectional_max_ps"];  df["piat_mean"] = df["bidirectional_mean_piat_ms"]
df["piat_std"]= df["bidirectional_stddev_piat_ms"]
for c in ["byt","pkt","dur_ms","bps","pps"]:
    df[c+"_log"] = np.log1p(np.clip(df[c], 0, None))

FLOW_V1 = ["bidirectional_duration_ms","bidirectional_packets","bidirectional_bytes",
           "src2dst_packets","src2dst_bytes","dst2src_packets","dst2src_bytes",
           "ps_mean","ps_std","ps_max","piat_mean","piat_std",
           "bytes_per_pkt","dn_ratio","dn_pkt_ratio","pps","bps",
           "is_udp","is_tcp","syn_ratio","psh_ratio","rst_cnt","fin_cnt"]
FLOW_V2 = FLOW_V1 + ["protocol","dst_port","src_port","ip_version",
                     "dst_port_is_443","dst_port_is_53"]
FLOW_V3 = FLOW_V2 + ["has_sni","sni_len","has_ja4","has_srvfp"]
FLOW_V4 = FLOW_V3 + ["src_oui","dst_oui"]
VIEWS2 = {"V1":FLOW_V1, "V2":FLOW_V2, "V3":FLOW_V3, "V4":FLOW_V4}

rows=[]
def ev(name, X, y, models, protocol="iid", tag=""):
    if protocol=="iid":
        cv = StratifiedKFold(5, shuffle=True, random_state=42)
        for mname, model in models.items():
            t0=time.time()
            pred = cross_val_predict(model, X, y, cv=cv, n_jobs=1)
            m = metrics(y, pred); m.update(dict(level=name, view=tag, model=mname,
                    protocol=protocol, n=len(y), n_feat=X.shape[1], sec=round(time.time()-t0,1)))
            rows.append(m)
            print(f"  [{protocol}] {name:8s} {tag:4s} {mname:7s} acc={m['acc']:.4f} f1={m['macro_f1']:.4f} bal={m['bal_acc']:.4f} n={m['n']} d={m['n_feat']}")
    return rows

# ---------- 1) model families at flow level ----------
print("\n########## 1) MODEL FAMILIES (flow level, subset APP_NDNS) ##########")
mask = ((~df.is_lan_bg) & (df.dst_port != 53)).values
d = df[mask].reset_index(drop=True); y = d["label"].values
for tag, cols in VIEWS2.items():
    X, _, _ = build_matrix(d, cols); X = X.values
    ev("flow", X, y, make_models(), "iid", tag)

# ---------- 2) temporal Day-5 OOD ----------
print("\n########## 2) TEMPORAL Day-5 OOD (train day1-4 / test day5) ##########")
from sklearn.metrics import accuracy_score, f1_score, balanced_accuracy_score
for sub_name, m2 in [("APP_NDNS", mask), ("ALL", np.ones(len(df),bool))]:
    d = df[m2].reset_index(drop=True)
    tr = d.capture_day != "day5"; te = d.capture_day == "day5"
    print(f"  -- {sub_name}: train={tr.sum()} test={te.sum()}  test dist={d[te].label.value_counts().to_dict()}")
    for tag, cols in VIEWS2.items():
        X, _, _ = build_matrix(d, cols); X = X.values
        Xtr, ytr = X[tr.values], d.label.values[tr.values]
        Xte, yte = X[te.values], d.label.values[te.values]
        for mname, model in make_models().items():
            model.fit(Xtr, ytr); pred = model.predict(Xte)
            m = dict(level="flow", view=tag, model=mname, protocol="day5", subset=sub_name,
                     n=int(te.sum()), n_feat=X.shape[1],
                     acc=accuracy_score(yte,pred),
                     macro_f1=f1_score(yte,pred,average="macro",labels=APPS,zero_division=0),
                     bal_acc=balanced_accuracy_score(yte,pred), sec=0)
            rows.append(m)
            print(f"  [day5] {sub_name:9s} {tag:4s} {mname:7s} acc={m['acc']:.4f} f1={m['macro_f1']:.4f} bal={m['bal_acc']:.4f}")

# ---------- 3) multi-flow aggregation ----------
print("\n########## 3) MULTI-FLOW AGGREGATION ##########")
for sub_name, m2 in [("ALL_NOISE_INCLUDED", np.ones(len(df),bool)),
                     ("APP_NDNS_ONLY", mask)]:
    d0 = df[m2].reset_index(drop=True)
    for lvl, keys in [("session", ["capture_file","src_ip"]),
                      ("burst30s", ["capture_file","src_ip","win30"])]:
        dd = d0.copy()
        if lvl == "burst30s":
            dd["win30"] = (pd.to_numeric(dd["bidirectional_first_seen_ms"], errors="coerce")
                           // 30000).astype("Int64")
        agg = aggregate(dd, keys)
        agg = agg[agg.label.isin(APPS)].reset_index(drop=True)
        print(f"  -- {sub_name} level={lvl}: {len(agg)} units, median flows/unit={agg.n_flows.median():.0f}")
        X = agg[AGG_COLS].replace([np.inf,-np.inf], np.nan).fillna(0).values.astype(np.float32)
        y = agg.label.values
        for mname, model in make_models().items():
            t0=time.time()
            pred = cross_val_predict(model, X, y,
                    cv=StratifiedKFold(5, shuffle=True, random_state=42), n_jobs=1)
            m = dict(level=lvl, view="AGG", model=mname, protocol="iid", subset=sub_name,
                     n=len(y), n_feat=X.shape[1], sec=round(time.time()-t0,1),
                     acc=accuracy_score(y,pred),
                     macro_f1=f1_score(y,pred,average="macro",labels=APPS,zero_division=0),
                     bal_acc=balanced_accuracy_score(y,pred))
            rows.append(m)
            print(f"  [{lvl}] {mname:7s} acc={m['acc']:.4f} f1={m['macro_f1']:.4f} bal={m['bal_acc']:.4f} n={m['n']}")

res = pd.DataFrame(rows)
res.to_csv(os.path.join(OUT,"results_B.csv"), index=False, encoding="utf-8-sig")
print("\nDONE", res.shape)
