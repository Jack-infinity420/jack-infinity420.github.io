# -*- coding: utf-8 -*-
"""Stage D: GEAD rule distillation on encrypted-flow features + fidelity/conciseness."""
import os, sys, json, warnings, itertools, time
warnings.filterwarnings("ignore")
os.environ.setdefault("JOBLIB_TEMP_FOLDER", r"C:\Windows\Temp")
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np, pandas as pd
from common import *
import gead as G

from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.metrics import accuracy_score, f1_score, balanced_accuracy_score

OUT = os.path.join(WORK, "gead"); os.makedirs(OUT, exist_ok=True)

RULE_FEATS = ["dur_ms","pkt","byt","dn_ratio","dn_pkt_ratio","bytes_per_pkt","pps","bps",
              "ps_mean","ps_std","ps_max","piat_mean","piat_std",
              "is_udp","syn_ratio","psh_ratio","rst_cnt","fin_cnt",
              "dst_port","has_sni","has_ja4","is_instant"]
CN = {"dur_ms":"流持续时长(ms)","pkt":"包数","byt":"字节数","dn_ratio":"下行字节占比",
      "dn_pkt_ratio":"下行包占比","bytes_per_pkt":"平均包长(字节)","pps":"包速率(包/秒)",
      "bps":"比特率(字节/秒)","ps_mean":"包长均值","ps_std":"包长标准差","ps_max":"最大包长",
      "piat_mean":"包间隔均值(ms)","piat_std":"包间隔标准差","is_udp":"是否UDP",
      "syn_ratio":"SYN占比","psh_ratio":"PSH占比","rst_cnt":"RST数","fin_cnt":"FIN数",
      "dst_port":"目的端口","has_sni":"有SNI","has_ja4":"有JA4指纹","is_instant":"瞬时流(时长=0)"}

df = load()
mask = ((~df.is_lan_bg) & (df.dst_port != 53)).values
d = df[mask].reset_index(drop=True)
print("rule-extraction corpus (APP_NDNS):", d.shape, d.label.value_counts().to_dict())

X = d[RULE_FEATS].replace([np.inf,-np.inf], np.nan).fillna(0).values.astype(np.float64)
y = d.label.values
day = d.capture_day.values

rng = np.random.default_rng(0)
idx = np.arange(len(d))
tr_mask = (day != "day5")
iid_idx = np.where(tr_mask)[0]
rng.shuffle(iid_idx)
cut = int(0.75*len(iid_idx))
tr_idx, iid_te = iid_idx[:cut], iid_idx[cut:]
ood_idx = np.where(day == "day5")[0]
print(f"train={len(tr_idx)} iid_test={len(iid_te)} ood_test(day5)={len(ood_idx)}")

# ---------------- black box: MLP ----------------
t0=time.time()
mlp = make_pipeline(StandardScaler(),
                    MLPClassifier(hidden_layer_sizes=(256,128,64), max_iter=600,
                                  early_stopping=True, n_iter_no_change=20, random_state=0))
mlp.fit(X[tr_idx], y[tr_idx])
print("MLP fitted %.1fs" % (time.time()-t0))
for nm, ii in [("IID", iid_te), ("OOD-day5", ood_idx)]:
    pr = mlp.predict(X[ii])
    print(f"  black box on {nm:9s}: acc={accuracy_score(y[ii],pr):.4f} "
          f"f1={f1_score(y[ii],pr,average='macro',labels=APPS,zero_division=0):.4f} "
          f"bal={balanced_accuracy_score(y[ii],pr):.4f} n={len(ii)}")

nn = G.NNFunc(mlp, mlp.classes_)
classes = [c for c in APPS if c in set(y)]
P_tr = nn.forward(X[tr_idx]); P_iid = nn.forward(X[iid_te]); P_ood = nn.forward(X[ood_idx])
y_mlp_iid = np.array(classes)[P_iid.argmax(1)]
y_mlp_ood = np.array(classes)[P_ood.argmax(1)]

def evaluate(M, tag):
    res = {}
    for nm, Xt, ytrue, ymod in [("iid", X[iid_te], y[iid_te], y_mlp_iid),
                                ("ood", X[ood_idx], y[ood_idx], y_mlp_ood)]:
        yt = M.predict(Xt)
        f = G.fidelity(ymod, yt, classes)
        f.update(dict(n_rules=M.n_rules(), tag=tag, split=nm,
                      acc_vs_true=accuracy_score(ytrue, yt),
                      f1_vs_true=f1_score(ytrue, yt, average="macro", labels=APPS, zero_division=0),
                      bal_vs_true=balanced_accuracy_score(ytrue, yt)))
        res[nm] = f
        print(f"  {tag:10s} {nm:4s} rules={f['n_rules']:4d} agree={f['agreement']:.4f} "
              f"posC={f['pos_consistency']:.4f} negR={f['neg_credibility']:.4f} "
              f"acc*={f['acc_vs_true']:.4f}")
    return res

rows=[]
md, ms = 4, 80
print("\n### baseline DT(hard labels from MLP) ###")
dt = DecisionTreeClassifier(max_depth=md+1, min_samples_leaf=ms, random_state=0)
dt.fit(X[tr_idx], np.array(classes)[P_tr.argmax(1)])
class DTWrap:
    def __init__(s, t): s.t=t
    def predict(s,X): return s.t.predict(X)
    def n_rules(s): return int((s.t.tree_.children_left==-1).sum())
r = evaluate(DTWrap(dt), "DT(hard)"); rows += [dict(v) for v in r.values()]

print("\n### baseline RT(IID): root regression trees only ###")
MRT = G.MergedRT(classes, len(classes)).fit_roots(X[tr_idx], P_tr, md, ms)
r = evaluate(MRT, "RT(IID)"); rows += [dict(v) for v in r.values()]

print("\n### GEAD: root + LC augmentation + subtrees ###")
t0=time.time()
MG = G.gead(X[tr_idx], P_tr, classes, nn, md=md, ms=ms, alpha_O=0.9, alpha_E=0.9,
            beta=0.1, N=6, sub_md=3, sub_ms=20, lc_min_n=40)
print("GEAD %.1fs" % (time.time()-t0))
r = evaluate(MG, "RT(GEAD)"); rows += [dict(v) for v in r.values()]

res = pd.DataFrame(rows)
res.to_csv(os.path.join(OUT,"fidelity_table.csv"), index=False, encoding="utf-8-sig")
print("\n=== FIDELITY TABLE ===")
print(res.pivot_table(index="tag", columns="split",
      values=["n_rules","agreement","pos_consistency","neg_credibility","acc_vs_true"]).round(4).to_string())

# ---------------- readable rules ----------------
print("\n=== RULE SET A: merged-tree argmax rules (RT-GEAD) ===")
y_pred_tr = MG.predict(X[tr_idx])
R = G.extract_rules(MG, RULE_FEATS, X[tr_idx], y_pred_tr, y[tr_idx], classes,
                    CN=CN, min_support=18, min_conf=0.55, top_k=5, max_conds=5)
for _,row in R.iterrows():
    print(f"  [{row.cls:9s} sup={row.support:4d} conf={row.confidence:.2f} prec={row.precision_true:.2f}]")
    print(f"     {row.rule_cn}")
R.drop(columns=["conds"]).to_csv(os.path.join(OUT,"rules_argmax.csv"), index=False, encoding="utf-8-sig")
print(f"\n  -> {len(R)} rules covering {R.cls.nunique()}/10 classes, "
      f"mean conditions {R.n_cond.mean():.2f}")

print("\n=== RULE SET B: per-class probability regions (all 10 apps) ===")
priors = pd.Series(y[tr_idx]).value_counts(normalize=True).to_dict()
RB = G.perclass_rules(MG, RULE_FEATS, X[tr_idx], classes, priors, CN=CN,
                      min_support=15, top_k=2, tau_mult=1.2)
for _,row in RB.iterrows():
    print(f"  [{row.cls:9s} sup={row['support']:4d} P={row.mean_prob:.2f} lift={row.lift:4.1f}x] {row.rule_cn}")
RB.drop(columns=["conds"]).to_csv(os.path.join(OUT,"rules_perclass.csv"), index=False, encoding="utf-8-sig")
print(f"\n  -> {len(RB)} rules covering {RB.cls.nunique()}/10 classes")

# ---------------- budget sweep (paper Fig.3 analogue) ----------------
print("\n=== CONCISENESS BUDGET SWEEP ===")
grid = [(3,200),(4,150),(4,80),(5,60),(5,40),(6,25),(7,15),(8,8)]
sweep=[]
for md2,ms2 in grid:
    dt2 = DecisionTreeClassifier(max_depth=md2+1, min_samples_leaf=ms2, random_state=0)
    dt2.fit(X[tr_idx], np.array(classes)[P_tr.argmax(1)])
    for nm_, Xt, ymod in [("iid",X[iid_te],y_mlp_iid), ("ood",X[ood_idx],y_mlp_ood)]:
        f = G.fidelity(ymod, dt2.predict(Xt), classes)
        sweep.append(dict(model="DT(hard)", md=md2, ms=ms2, split=nm_,
                          n_rules=int((dt2.tree_.children_left==-1).sum()), **f))
    for nm_, Xt, ymod in [("iid",X[iid_te],y_mlp_iid), ("ood",X[ood_idx],y_mlp_ood)]:
        M2 = G.MergedRT(classes, len(classes)).fit_roots(X[tr_idx], P_tr, md2, ms2)
        f = G.fidelity(ymod, M2.predict(Xt), classes)
        sweep.append(dict(model="RT(IID)", md=md2, ms=ms2, split=nm_,
                          n_rules=M2.n_rules(), **f))
    M3 = G.gead(X[tr_idx], P_tr, classes, nn, md=md2, ms=ms2, N=3, sub_md=3,
                sub_ms=max(15, ms2//4), lc_min_n=40, verbose=False)
    for nm_, Xt, ymod in [("iid",X[iid_te],y_mlp_iid), ("ood",X[ood_idx],y_mlp_ood)]:
        f = G.fidelity(ymod, M3.predict(Xt), classes)
        sweep.append(dict(model="RT(GEAD)", md=md2, ms=ms2, split=nm_,
                          n_rules=M3.n_rules(), **f))
    print(f"  md={md2} ms={ms2}: DT rules={sweep[-6]['n_rules']:4d} "
          f"RT rules={sweep[-4]['n_rules']:4d} GEAD rules={sweep[-2]['n_rules']:4d}")

S = pd.DataFrame(sweep)
S.to_csv(os.path.join(OUT,"budget_sweep.csv"), index=False, encoding="utf-8-sig")

# plot
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
fig, axes = plt.subplots(1,2, figsize=(11,4), dpi=150)
for ax, split in zip(axes, ["iid","ood"]):
    for mname, mk in [("DT(hard)","o--"),("RT(IID)","s-"),("RT(GEAD)","^-")]:
        s = S[(S.model==mname)&(S.split==split)].sort_values("n_rules")
        ax.plot(s.n_rules, s.pos_consistency, mk, label=f"{mname} posC")
        ax.plot(s.n_rules, s.neg_credibility, mk, alpha=.35, label=f"{mname} negR")
    ax.set_xscale("log"); ax.set_xlabel("# rules (conciseness budget)")
    ax.set_ylabel("fidelity"); ax.set_title(f"split = {split}"); ax.grid(alpha=.3)
    ax.legend(fontsize=7)
fig.tight_layout(); fig.savefig(os.path.join(OUT,"fidelity_vs_rules.png"))
print("\nsaved", OUT)
