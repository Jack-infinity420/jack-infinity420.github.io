# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "_work"))
import pandas as pd
from common import load
df = load(verbose=False)
for v in [212, 66, 60, 330, 167, 218]:
    s = df[df.bidirectional_max_ps == v]
    if not len(s): continue
    print(f"\n--- max_ps == {v}  n={len(s)} ---")
    print("  protocol:", s.protocol.value_counts().head(3).to_dict())
    print("  dst_port:", s.dst_port.value_counts().head(4).to_dict())
    print("  包数中位:", int(s.bidirectional_packets.median()),
          " 字节中位:", int(s.bidirectional_bytes.median()))
    print("  app:", s.label.value_counts().head(4).to_dict())
print("\n=== 各种大小的 '单包流' 有多少（packets==1）===")
one = df[df.bidirectional_packets == 1]
print("单包流总数:", len(one), " 占比 %.1f%%" % (100*len(one)/len(df)))
print("单包流大小分布:", one.bidirectional_max_ps.value_counts().head(8).to_dict())
print("单包流的 dst_port:", one.dst_port.value_counts().head(6).to_dict())
print("单包流的 protocol:", one.protocol.value_counts().head(4).to_dict())
