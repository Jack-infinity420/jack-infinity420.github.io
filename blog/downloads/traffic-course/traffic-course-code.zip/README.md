# 网络流量课程 · 配套代码包

配套文章（lvjf.space/blog）：

- 网络流量入门（零）：课程导览与能力阶梯
- 网络流量入门（一）：从比特到流
- 网络流量入门（二）：92 个特征是怎么算出来的
- 网络流量入门（三）：从端口法到 nDPI
- 网络流量入门（四）：Wireshark 动手实验与自测
- 加密社交 App 流量分析（一）～（四）

## 目录

```
analysis/                数据分析与规则提炼脚本（Python 3.12）
  common.py              数据载入 + 23 个派生特征 + 5 个特征视图
  gead.py                GEAD 六步实现（MLP 前向/反向、CART 蒸馏、LC 增广、合并树、规则生成）
  01_audit.py            基础审计（列画像、标签交叉表）
  02_deep_audit.py       深度审计（设备/时间/指纹纯度）
  03_noise.py            背景流量（SSID/mDNS/DNS）占比分析
  04_structure.py        设备与会话结构探查
  10_stageA_views.py     特征视图消融（V1..V5）
  11_stageB.py           模型族 + Day-5 时间外推 + 多流聚合
  12_stageC_leakage.py   泄漏/捷径审计（IID vs 设备留出）
  13_gead_run.py         规则蒸馏主实验（保真度/简洁度/可读规则）
  14_rules_human.py      真标签浅树规则 + 专家核查 + 图表
  15_tables.py           汇总所有表与图
  16_gead_tune.py        GEAD 超参敏感性
  18_budgettable.py      等预算表格
  19_equal_budget.py     等规则预算公平比较
  20_gead_bestshot.py    GEAD 最优配置搜索
capture/                 抓包与绘图脚本
  build_demo_pcap.py     用 scapy 生成 27 包教学抓包 demo_handshake.pcap
  make_intuition_figs.py 用真实数据画包长谱/流长/体量/端口四张图
  probe_sizes.py / probe2..5.py   数据探查小脚本（结论核对用）
```

## 运行

```bash
pip install pandas numpy scikit-learn matplotlib scapy tabulate
python analysis/10_stageA_views.py      # 需把 common.py 里的 BASE 指向数据集目录
```

`analysis/common.py` 顶部的 `BASE` 需改成你自己的数据目录（10 个 App 的 CSV 放在那里）。

数据来源：Mobile Social Media Traffic Fingerprinting Dataset（10 个 Android 社交 App × 5 天，
NFStream 抽取的双向流级特征，25,116 条 × 92 列）。
