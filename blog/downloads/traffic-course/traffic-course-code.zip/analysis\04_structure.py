# -*- coding: utf-8 -*-
"""Structure probe: devices, sessions, and whether device identity is the real signal."""
import os, sys, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np, pandas as pd
from common import *
pd.set_option("display.width", 250)
df = load()

print("=== per capture_file: flows, src_ip, src_mac ===")
g = df.groupby("capture_file").agg(flows=("id","size"), ips=("src_ip","nunique"), macs=("src_mac","nunique"))
print(g.sort_values("flows", ascending=False).head(15).to_string())

print("\n=== flows per (capture_file, src_ip) distribution ===")
sz = df.groupby(["capture_file","src_ip"]).size()
print(sz.describe().round(1).to_string())
print("share of flows in top-20 groups: %.3f" % (sz.nlargest(20).sum()/len(df)))

print("\n=== is src_ip -> src_mac a stable 1:1 map? ===")
m = df.groupby("src_ip")["src_mac"].nunique()
print("src_ip with >1 mac:", (m>1).sum(), "of", len(m))
print(m.sort_values(ascending=False).head(8).to_string())

print("\n=== which macs carry app traffic? (rows per (mac,label) top) ===")
t = df.groupby(["src_mac"])["label"].agg(n="size", nu="nunique")
print(t.sort_values("n", ascending=False).head(12).to_string())
print("\nmac->label purity: weighted",
      round((df.groupby("src_mac")["label"].apply(lambda x: x.value_counts(normalize=True).iloc[0]) * t["n"]).sum()/t["n"].sum(),4))

print("\n=== does each label use a distinct device set? (Jaccard of mac sets) ===")
sets = {a:set(df[df.label==a].src_mac.unique()) for a in APPS}
J = pd.DataFrame(index=APPS, columns=APPS, dtype=float)
for a in APPS:
    for b in APPS:
        J.loc[a,b] = len(sets[a]&sets[b])/max(len(sets[a]|sets[b]),1)
print(J.round(2).to_string())

print("\n=== per label: #distinct mac, #distinct ip, flows/mac ===")
r = df.groupby("label").agg(flows=("id","size"), macs=("src_mac","nunique"),
                            ips=("src_ip","nunique"), days=("capture_day","nunique"))
r["flows_per_mac"] = (r.flows/r.macs).round(1)
print(r.sort_values("flows", ascending=False).to_string())

print("\n=== growth of device set over days (per label) ===")
print(pd.crosstab([df.label, df.capture_day], df.src_mac.nunique()).to_string())
