# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "_work"))
import pandas as pd, numpy as np
from common import load
df = load(verbose=False)
print("duration_ms  max:", df.bidirectional_duration_ms.max(),
      " 次大:", sorted(df.bidirectional_duration_ms)[-2])
print("mean_piat_ms max:", df.bidirectional_mean_piat_ms.max(),
      " max_piat max:", df.bidirectional_max_piat_ms.max())
print("duration==0 的流:", int((df.bidirectional_duration_ms == 0).sum()))
print("duration > 1799000 的流:", int((df.bidirectional_duration_ms > 1799000).sum()))
print("max_piat >= 119000 的流:", int((df.bidirectional_max_piat_ms >= 119000).sum()))
print()
print("expiration_id 分布(若有):")
if "expiration_id" in df.columns:
    print(df.expiration_id.value_counts().to_string())
print()
d = df[(~df.is_lan_bg) & (df.dst_port != 53)]
print("每 App 的 bytes_per_pkt / psh_ratio / syn_ratio 中位数:")
print(d.groupby("label")[["bytes_per_pkt", "psh_ratio", "syn_ratio",
                          "bidirectional_mean_piat_ms", "bidirectional_stddev_ps"]]
      .median().round(3).to_string())
print()
print("flags: 有 SYN 的流占比 %.3f；SYN==1 的占 %.3f；SYN>1 的占 %.3f" % (
    (df.bidirectional_syn_packets > 0).mean(),
    (df.bidirectional_syn_packets == 1).mean(),
    (df.bidirectional_syn_packets > 1).mean()))
print("FIN>0 占比 %.3f; RST>0 占比 %.3f; PSH>0 占比 %.3f" % (
    (df.bidirectional_fin_packets > 0).mean(),
    (df.bidirectional_rst_packets > 0).mean(),
    (df.bidirectional_psh_packets > 0).mean()))
