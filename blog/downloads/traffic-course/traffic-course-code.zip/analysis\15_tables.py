﻿# -*- coding: utf-8 -*-
"""Assemble markdown tables + figures for the final report."""
import os, sys, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np, pandas as pd
from common import *
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

G = os.path.join(WORK, "gead")
OUTMD = os.path.join(WORK, "tables.md")
md = []

# ---------- Table: feature-view ablation (stage A) ----------
A = pd.read_csv(os.path.join(WORK,"results_A_views.csv"))
A["model"] = A["model"].str.replace("HistGradientBoostingClassifier","HGB").str.replace("RandomForestClassifier","RF")
md.append("## T1 特征视图消融（5 折 IID，准确率）\n")
t = A[A.model=="HGB"].pivot_table(index="view", columns="subset", values="acc").round(4)
md.append(t.to_markdown()+"\n")
md.append("表 T1b macro-F1\n"); md.append(A[A.model=="HGB"].pivot_table(index="view",columns="subset",values="macro_f1").round(4).to_markdown()+"\n")

# ---------- Table: model families flow level ----------
B = pd.read_csv(os.path.join(WORK,"results_B.csv"))
fl = B[(B.level=="flow")&(B.protocol=="iid")&(B.subset.isna())] if "subset" in B else B
fl = B[(B.level=="flow")&(B.protocol=="iid")]
if "subset" in fl: fl = fl[fl.subset.isna()]
md.append("## T2 模型族对比（flow 级，APP_NDNS，IID 5 折）\n")
md.append(fl.pivot_table(index="view", columns="model", values="acc").round(4).to_markdown()+"\n")

# ---------- Table: temporal day5 ----------
td = B[B.protocol=="day5"]
md.append("## T3 时间外推 Day-5（train day1-4 → test day5）\n")
md.append(td.pivot_table(index=["subset","view"], columns="model", values="acc").round(4).to_markdown()+"\n")
md.append("\nmacro-F1：\n"); md.append(td.pivot_table(index=["subset","view"], columns="model", values="macro_f1").round(4).to_markdown()+"\n")

# ---------- Table: aggregation ----------
ag = B[B.view=="AGG"]
md.append("## T4 多流聚合\n")
md.append(ag.pivot_table(index=["subset","level"], columns="model", values="acc").round(4).to_markdown()+"\n")

# ---------- Table: leakage ----------
C = pd.read_csv(os.path.join(WORK,"results_C_leakage.csv"))
md.append("## T5 泄漏/捷径审计（IID vs 设备留出）\n")
md.append(C.pivot_table(index="view", columns="protocol", values="acc").round(4).to_markdown()+"\n")

# ---------- Table: fidelity ----------
F = pd.read_csv(os.path.join(G,"fidelity_table.csv"))
md.append("## T6 规则蒸馏保真度/简洁度\n")
p = F.pivot_table(index="tag", columns="split",
                  values=["n_rules","agreement","pos_consistency","neg_credibility","acc_vs_true"])
md.append(p.round(4).to_markdown()+"\n")

# ---------- matched-budget table ----------
S = pd.read_csv(os.path.join(G,"budget_sweep.csv"))
def at_budget(model, split, budget):
    s = S[(S.model==model)&(S.split==split)].sort_values("n_rules")
    # linear interpolation on log rules
    x = np.log10(s.n_rules.values); 
    return dict(posC=float(np.interp(np.log10(budget), x, s.pos_consistency.values)),
                negR=float(np.interp(np.log10(budget), x, s.neg_credibility.values)),
                rules=int(s.n_rules.min()), max_rules=int(s.n_rules.max()))
rows=[]
for split in ["iid","ood"]:
    for b in [30,100,300,1000]:
        for m in ["DT(hard)","RT(IID)","RT(GEAD)"]:
            d = at_budget(m, split, b); d.update(dict(split=split, budget=b, model=m))
            rows.append(d)
MB = pd.DataFrame(rows)
md.append("## T7 等规则预算下的保真度（对数插值）\n")
md.append(MB.pivot_table(index=["split","budget"], columns="model",
                         values=["posC","negR"]).round(3).to_markdown()+"\n")

# ---------- figure: view ablation ----------
fig, ax = plt.subplots(figsize=(7.2,4), dpi=150)
views = ["V1_flow_stats","V2_l4_identity","V3_tls_meta","V4_sni_oui","V5_dpi_oracle"]
lab = ["V1\nflow stats","V2\n+L4 id","V3\n+TLS fp","V4\n+SNI/OUI","V5\n+DPI"]
for sub, mk in [("ALL","o-"),("APP","s-"),("APP_NDNS","^-")]:
    s = A[(A.model=="HGB")&(A.subset==sub)].set_index("view").loc[views]
    ax.plot(lab, s.acc.values, mk, label=sub)
    for i,v in enumerate(s.acc.values): ax.annotate(f"{v:.3f}", (i,v), fontsize=7,
        textcoords="offset points", xytext=(0,6), ha="center")
ax.set_ylabel("accuracy (5-fold IID)"); ax.legend(); ax.grid(alpha=.3)
ax.set_title("feature-view ablation (HGB)")
fig.tight_layout(); fig.savefig(os.path.join(G,"view_ablation.png")); plt.close(fig)

# ---------- figure: device-heldout ----------
fig, ax = plt.subplots(figsize=(6.4,4), dpi=150)
cv = C.pivot_table(index="view", columns="protocol", values="acc")
cv = cv.loc[[v for v in ["V1","V2","V3","V3+src_oui","V3+dst_oui","V3+both_oui"] if v in cv.index]]
x = np.arange(len(cv))
ax.bar(x-0.2, cv["iid"], 0.4, label="IID 5-fold")
ax.bar(x+0.2, cv["mac"], 0.4, label="unseen-device (GroupKFold by src_mac)")
for i,(a,b) in enumerate(zip(cv["iid"], cv["mac"])):
    ax.annotate(f"{a:.2f}", (i-0.2,a), ha="center", fontsize=7, xytext=(0,2), textcoords="offset points")
    ax.annotate(f"{b:.2f}", (i+0.2,b), ha="center", fontsize=7, xytext=(0,2), textcoords="offset points")
ax.set_xticks(x); ax.set_xticklabels(cv.index, fontsize=8, rotation=20)
ax.set_ylabel("accuracy"); ax.legend(fontsize=8); ax.grid(alpha=.3, axis="y")
ax.set_title("generalisation to unseen devices")
fig.tight_layout(); fig.savefig(os.path.join(G,"device_holdout.png")); plt.close(fig)

open(OUTMD,"w",encoding="utf-8").write("\n".join(md))
print("\n".join(md)[:6000])
print("\nsaved", OUTMD)
