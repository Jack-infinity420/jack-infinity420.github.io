# -*- coding: utf-8 -*-
"""Give GEAD its best shot at a fixed rule budget before comparing."""
import os, sys, warnings, itertools
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np, pandas as pd
from common import *
import gead as G
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier

RULE_FEATS = ["dur_ms","pkt","byt","dn_ratio","dn_pkt_ratio","bytes_per_pkt","pps","bps",
              "ps_mean","ps_std","ps_max","piat_mean","piat_std","is_udp","syn_ratio",
              "psh_ratio","rst_cnt","fin_cnt","dst_port","has_sni","has_ja4","is_instant"]
df = load()
d = df[((~df.is_lan_bg) & (df.dst_port != 53))].reset_index(drop=True)
X = d[RULE_FEATS].replace([np.inf,-np.inf], np.nan).fillna(0).values.astype(np.float64)
y = d.label.values; day = d.capture_day.values
rng = np.random.default_rng(0)
iid = np.where(day!="day5")[0]; rng.shuffle(iid)
cut=int(0.75*len(iid)); tr, te = iid[:cut], iid[cut:]
ood = np.where(day=="day5")[0]
mlp = make_pipeline(StandardScaler(), MLPClassifier((256,128,64), max_iter=600,
      early_stopping=True, n_iter_no_change=20, random_state=0)).fit(X[tr], y[tr])
nn = G.NNFunc(mlp, mlp.classes_); classes=list(mlp.classes_)
P=nn.forward(X[tr]); Pi=nn.forward(X[te]); Po=nn.forward(X[ood])
yi=np.array(classes)[Pi.argmax(1)]; yo=np.array(classes)[Po.argmax(1)]

rows=[]
for md, sub_md, ms, sub_ms, ood_frac, N in [
    (3,5,200,10,0.0,6),(3,5,150,10,0.5,6),(4,4,150,12,0.0,6),(4,4,120,12,0.5,6),
    (4,6,120,8,0.0,8),(5,4,90,10,0.5,6),(5,3,70,14,0.0,6),(4,5,100,10,0.25,10)]:
    M = G.gead(X[tr], P, classes, nn, md=md, ms=ms, N=N, sub_md=sub_md, sub_ms=sub_ms,
               ood_frac=ood_frac, lc_min_n=40, verbose=False)
    fi=G.fidelity(yi,M.predict(X[te]),classes); fo=G.fidelity(yo,M.predict(X[ood]),classes)
    r=dict(md=md,sub_md=sub_md,ms=ms,sub_ms=sub_ms,ood_frac=ood_frac,N=N,rules=M.n_rules(),
           iid_posC=round(fi["pos_consistency"],3),ood_posC=round(fo["pos_consistency"],3),
           iid_negR=round(fi["neg_credibility"],3),ood_negR=round(fo["neg_credibility"],3),
           iid_agree=round(fi["agreement"],3),ood_agree=round(fo["agreement"],3))
    rows.append(r); print(r)
R=pd.DataFrame(rows).sort_values("iid_posC",ascending=False)
R.to_csv(os.path.join(WORK,"gead","gead_best_shot.csv"),index=False,encoding="utf-8-sig")
print("\nbest:\n", R.head(4).to_string(index=False))
