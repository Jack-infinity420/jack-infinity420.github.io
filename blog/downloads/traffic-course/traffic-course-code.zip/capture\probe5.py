# -*- coding: utf-8 -*-
import os, re, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "_work"))
import pandas as pd
from common import load
df = load(verbose=False)
s = df.requested_server_name.fillna("")
valid = s.str.match(r"^(?=.{1,253}$)([a-zA-Z0-9_]([a-zA-Z0-9_-]{0,61}[a-zA-Z0-9_])?\.)+[a-zA-Z]{2,63}$")
ip_like = s.str.match(r"^\d{1,3}(\.\d{1,3}){3}$")
print("requested_server_name 非空: %d (%.1f%%)" % ((s != "").sum(), 100*(s != "").mean()))
print("  其中像合法域名: %d (%.1f%%)" % (valid.sum(), 100*valid.mean()))
print("  其中像 IP 字面量: %d (%.1f%%)" % (ip_like.sum(), 100*ip_like.mean()))
print("\nIP 字面量的 top 值:"); print(s[ip_like].value_counts().head(5).to_string())
print("\n非法域名的 top 值:"); print(s[(s != "") & ~valid & ~ip_like].value_counts().head(8).to_string())
print("\n合法域名里，跨 App 覆盖数 top 10:")
sub = df[valid]
g = sub.groupby("requested_server_name")["label"].agg(cnt="size", nu="nunique",
        purity=lambda x: x.value_counts(normalize=True).iloc[0])
print(g.sort_values("cnt", ascending=False).head(10).round(3).to_string())
print("\n合法域名的加权纯度: %.3f" % ((g.purity*g.cnt).sum()/g.cnt.sum()))
print("\n每 App 的合法域名覆盖率:")
print(df.assign(v=valid).groupby("label").v.mean().round(3).sort_values(ascending=False).to_string())
