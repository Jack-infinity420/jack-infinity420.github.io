# -*- coding: utf-8 -*-
"""Build a small, purpose-made teaching capture (Ethernet/PCAP) so every
abstraction in the tutorial can actually be *seen* in Wireshark.

Contents
  1. DNS query/answer for mmg.whatsapp.net            (UDP/53)
  2. TCP 3-way handshake with realistic options       (SYN = 60-byte IP packet)
  3. TLS 1.3 ClientHello carrying SNI                 (the "last plaintext")
  4. ServerHello, then encrypted Application Data     (record type 23)
  5. A second connection killed by RST                (the RST pattern)
  6. SSDP M-SEARCH + mDNS query                       (background noise)
  7. One UDP/443 datagram with random bytes           (what QUIC looks like)
"""
import os, struct
from scapy.all import (Ether, IP, TCP, UDP, DNS, DNSQR, DNSRR, Raw, ICMP,
                       Padding, wrpcap, PcapWriter)
from scapy.packet import Raw as _Raw

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "demo_handshake.pcap")
C_MAC, S_MAC = "3c:5a:b4:11:22:33", "d4:01:c3:aa:bb:cc"
C_IP, C_PORT = "10.20.30.40", 51423
S_IP, S_PORT = "203.0.113.10", 443          # 203.0.113.0/24 = RFC 5737 TEST-NET-3

T0 = 1700000000.0
pkts, t = [], T0


def add(p, dt):
    global t
    t += dt
    # real NICs pad any frame shorter than 60 bytes (Ethernet minimum on the wire)
    n = len(bytes(p))
    if n < 60:
        p = p / Padding(b"\x00" * (60 - n))
    p.time = t
    # force checksum recomputation
    if p.haslayer(IP):
        del p[IP].chksum
    if p.haslayer(TCP):
        del p[TCP].chksum
    if p.haslayer(UDP):
        del p[UDP].chksum
    pkts.append(p)
    return p


def L2(dst, src=S_MAC):
    return Ether(dst=dst, src=src)


# ----------------------------------------------------------------- TLS builders
def _ext(t, data):
    return struct.pack(">HH", t, len(data)) + data


def _hs(t, body):
    return bytes([t]) + len(body).to_bytes(3, "big") + body


def _rec(ct, frag, ver=b"\x03\x03"):
    return bytes([ct]) + ver + struct.pack(">H", len(frag)) + frag


def client_hello(sni):
    body = b"\x03\x03" + os.urandom(32) + b"\x20" + os.urandom(32)
    cs = [0x1301, 0x1302, 0x1303, 0xC02B, 0xC02F, 0xC02C, 0xC030,
          0xCCA9, 0xCCA8, 0xC013, 0xC014, 0x009C, 0x009D, 0x002F, 0x0035]
    body += struct.pack(">H", len(cs) * 2) + b"".join(struct.pack(">H", c) for c in cs)
    body += b"\x01\x00"
    name = sni.encode()
    sni_ext = _ext(0x0000, struct.pack(">H", len(name) + 3) + b"\x00" +
                   struct.pack(">H", len(name)) + name)
    groups = struct.pack(">H", 6) + b"".join(struct.pack(">H", g)
                                             for g in (0x001D, 0x0017, 0x0018))
    alpn = b"\x00\x0c\x02h2\x08http/1.1"
    sigs = [0x0403, 0x0804, 0x0401, 0x0503, 0x0805, 0x0501, 0x0806, 0x0601]
    exts = (sni_ext
            + _ext(0x0017, b"")                                  # extended_master_secret
            + _ext(0xFF01, b"\x00")                              # renegotiation_info
            + _ext(0x000A, groups)                               # supported_groups
            + _ext(0x000B, b"\x01\x00")                          # ec_point_formats
            + _ext(0x0023, b"")                                  # session_ticket
            + _ext(0x0010, alpn)                                 # ALPN
            + _ext(0x000D, struct.pack(">H", len(sigs) * 2) +
                   b"".join(struct.pack(">H", s) for s in sigs))  # signature_algorithms
            + _ext(0x002B, b"\x04\x03\x04\x03\x03")               # supported_versions
            + _ext(0x002D, b"\x01\x01")                           # psk_key_exchange_modes
            + _ext(0x0033, b"\x00\x24\x00\x1d\x00\x20" + os.urandom(32)))  # key_share
    body += struct.pack(">H", len(exts)) + exts
    return _rec(0x16, _hs(0x01, body))


def server_hello():
    body = b"\x03\x03" + os.urandom(32) + b"\x20" + os.urandom(32)
    body += b"\x13\x01" + b"\x00"
    exts = _ext(0x002B, b"\x03\x04") + _ext(0x0033, b"\x00\x1d\x00\x20" + os.urandom(32))
    body += struct.pack(">H", len(exts)) + exts
    return _rec(0x16, _hs(0x02, body))


def app_data(n):
    return _rec(0x17, os.urandom(n))


# ------------------------------------------------------------- 1. DNS
add(L2("ff:ff:ff:ff:ff:ff", C_MAC) /
    IP(src=C_IP, dst="8.8.8.8") /
    UDP(sport=41234, dport=53) /
    DNS(id=0x1234, rd=1, qd=DNSQR(qname="mmg.whatsapp.net", qtype="A")), 0.000)
add(L2(C_MAC, "d4:01:c3:aa:bb:cc") /
    IP(src="8.8.8.8", dst=C_IP) /
    UDP(sport=53, dport=41234) /
    DNS(id=0x1234, qr=1, aa=0, rd=1, ra=1,
        qd=DNSQR(qname="mmg.whatsapp.net", qtype="A"),
        an=DNSRR(rrname="mmg.whatsapp.net", type="A", ttl=60, rdata=S_IP),
        ancount=1), 0.021)

# ------------------------------------------- 2/3/4. one HTTPS conversation
win = 64240
tcp_opts = [("MSS", 1460), ("SAckOK", b""), ("WScale", 7), ("NOP", None),
            ("NOP", None), ("Timestamp", (123456789, 0))]
cnxt, snxt = 1000, 5000          # next sequence numbers, kept exact

add(L2(S_MAC, C_MAC) / IP(src=C_IP, dst=S_IP) /
    TCP(sport=C_PORT, dport=S_PORT, flags="S", seq=cnxt, window=win, options=tcp_opts), 0.031)
cnxt += 1
add(L2(C_MAC, S_MAC) / IP(src=S_IP, dst=C_IP) /
    TCP(sport=S_PORT, dport=C_PORT, flags="SA", seq=snxt, ack=cnxt,
        window=win, options=tcp_opts), 0.041)
snxt += 1
add(L2(S_MAC, C_MAC) / IP(src=C_IP, dst=S_IP) /
    TCP(sport=C_PORT, dport=S_PORT, flags="A", seq=cnxt, ack=snxt, window=win), 0.0002)

ch = client_hello("mmg.whatsapp.net")
add(L2(S_MAC, C_MAC) / IP(src=C_IP, dst=S_IP) /
    TCP(sport=C_PORT, dport=S_PORT, flags="PA", seq=cnxt, ack=snxt,
        window=win) / Raw(ch), 0.0008)
cnxt += len(ch)
add(L2(C_MAC, S_MAC) / IP(src=S_IP, dst=C_IP) /
    TCP(sport=S_PORT, dport=C_PORT, flags="A", seq=snxt, ack=cnxt, window=win), 0.0219)

sh = server_hello()
add(L2(C_MAC, S_MAC) / IP(src=S_IP, dst=C_IP) /
    TCP(sport=S_PORT, dport=C_PORT, flags="PA", seq=snxt, ack=cnxt,
        window=win) / Raw(sh), 0.0001)
snxt += len(sh)
add(L2(S_MAC, C_MAC) / IP(src=C_IP, dst=S_IP) /
    TCP(sport=C_PORT, dport=S_PORT, flags="A", seq=cnxt, ack=snxt, window=win), 0.0003)

# server pushes 3 MSS-sized segments of encrypted application data
for n, dt in [(1380, 0.0926), (1460, 0.0734), (1060, 0.0712)]:
    rec = app_data(n - 5)                       # IP len = 40 + n  (<=1500)
    add(L2(C_MAC, S_MAC) / IP(src=S_IP, dst=C_IP) /
        TCP(sport=S_PORT, dport=C_PORT, flags="PA", seq=snxt, ack=cnxt,
            window=win) / Raw(rec), dt)
    snxt += len(rec)

add(L2(S_MAC, C_MAC) / IP(src=C_IP, dst=S_IP) /
    TCP(sport=C_PORT, dport=S_PORT, flags="A", seq=cnxt, ack=snxt, window=win), 0.0004)

# client uploads one small request, then the flow is closed normally
creq = app_data(260)
add(L2(S_MAC, C_MAC) / IP(src=C_IP, dst=S_IP) /
    TCP(sport=C_PORT, dport=S_PORT, flags="PA", seq=cnxt, ack=snxt,
        window=win) / Raw(creq), 0.1520)
cnxt += len(creq)
add(L2(C_MAC, S_MAC) / IP(src=S_IP, dst=C_IP) /
    TCP(sport=S_PORT, dport=C_PORT, flags="A", seq=snxt, ack=cnxt, window=win), 0.0190)
add(L2(S_MAC, C_MAC) / IP(src=C_IP, dst=S_IP) /
    TCP(sport=C_PORT, dport=S_PORT, flags="FA", seq=cnxt, ack=snxt, window=win), 0.2260)
cnxt += 1
add(L2(C_MAC, S_MAC) / IP(src=S_IP, dst=C_IP) /
    TCP(sport=S_PORT, dport=C_PORT, flags="FA", seq=snxt, ack=cnxt, window=win), 0.0009)
snxt += 1
add(L2(S_MAC, C_MAC) / IP(src=C_IP, dst=S_IP) /
    TCP(sport=C_PORT, dport=S_PORT, flags="A", seq=cnxt, ack=snxt, window=win), 0.0001)

# ------------------------------------------------------ 5. a connection killed by RST
rsq = 7777
add(L2(S_MAC, C_MAC) / IP(src=C_IP, dst="203.0.113.55") /
    TCP(sport=51500, dport=443, flags="S", seq=rsq, window=win, options=tcp_opts), 0.4120)
add(L2(C_MAC, S_MAC) / IP(src="203.0.113.55", dst=C_IP) /
    TCP(sport=443, dport=51500, flags="SA", seq=9000, ack=rsq + 1, window=win, options=tcp_opts), 0.0104)
add(L2(S_MAC, C_MAC) / IP(src=C_IP, dst="203.0.113.55") /
    TCP(sport=51500, dport=443, flags="A", seq=rsq + 1, ack=9001, window=win), 0.0002)
tch = client_hello("track.example.net")
add(L2(S_MAC, C_MAC) / IP(src=C_IP, dst="203.0.113.55") /
    TCP(sport=51500, dport=443, flags="PA", seq=rsq + 1, ack=9001, window=win) / Raw(tch), 0.0001)
add(L2(C_MAC, S_MAC) / IP(src="203.0.113.55", dst=C_IP) /
    TCP(sport=443, dport=51500, flags="R", seq=9001, window=0), 0.0121)

# ------------------------------------------------------------- 6. background noise
msearch = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n"
           'MAN: "ssdp:discover"\r\nMX: 1\r\nST: ssdp:all\r\n\r\n').encode()
add(L2("01:00:5e:7f:ff:fa", C_MAC) / IP(src=C_IP, dst="239.255.255.250", ttl=2) /
    UDP(sport=1900, dport=1900) / Raw(msearch), 1.2010)
add(L2("01:00:5e:00:00:fb", C_MAC) / IP(src=C_IP, dst="224.0.0.251", ttl=255) /
    UDP(sport=5353, dport=5353) /
    DNS(id=0, rd=0, qd=DNSQR(qname="_spotify-connect._tcp.local", qtype="PTR")), 0.3010)
add(L2(C_MAC, "d4:01:c3:aa:bb:cc") / IP(src="192.168.1.1", dst=C_IP) / ICMP(type=8) /
    Raw(b"\x00" * 32), 0.0110)

# ------------------------------------------------------------- 7. something that looks like QUIC
quic = b"\xc3\x00\x00\x00\x01\x08" + os.urandom(1150)
add(L2(S_MAC, C_MAC) / IP(src=C_IP, dst="203.0.113.77") /
    UDP(sport=52000, dport=443) / Raw(quic), 2.4220)

wrpcap(OUT, pkts)
print("wrote", OUT, len(pkts), "packets,", os.path.getsize(OUT), "bytes")
