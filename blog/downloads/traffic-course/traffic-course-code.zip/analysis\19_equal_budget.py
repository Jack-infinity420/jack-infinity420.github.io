# -*- coding: utf-8 -*-
"""Equal rule-budget comparison (paper Fig.3 protocol): tune each explainer's
capacity so the three rule sets land on the same conciseness budget."""
import os, sys, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np, pandas as pd
from common import *
import gead as G
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier

RULE_FEATS = ["dur_ms","pkt","byt","dn_ratio","dn_pkt_ratio","bytes_per_pkt","pps","bps",
              "ps_mean","ps_std","ps_max","piat_mean","piat_std","is_udp","syn_ratio",
              "psh_ratio","rst_cnt","fin_cnt","dst_port","has_sni","has_ja4","is_instant"]
df = load()
d = df[((~df.is_lan_bg) & (df.dst_port != 53))].reset_index(drop=True)
X = d[RULE_FEATS].replace([np.inf,-np.inf], np.nan).fillna(0).values.astype(np.float64)
y = d.label.values; day = d.capture_day.values
rng = np.random.default_rng(0)
iid = np.where(day!="day5")[0]; rng.shuffle(iid)
cut = int(0.75*len(iid)); tr, te = iid[:cut], iid[cut:]
ood = np.where(day=="day5")[0]
mlp = make_pipeline(StandardScaler(), MLPClassifier((256,128,64), max_iter=600,
      early_stopping=True, n_iter_no_change=20, random_state=0)).fit(X[tr], y[tr])
nn = G.NNFunc(mlp, mlp.classes_); classes=list(mlp.classes_)
P = nn.forward(X[tr]); Pi = nn.forward(X[te]); Po = nn.forward(X[ood])
yi = np.array(classes)[Pi.argmax(1)]; yo = np.array(classes)[Po.argmax(1)]
yhard = np.array(classes)[P.argmax(1)]

rows=[]
CFG_DT  = [(8,6),(9,5),(10,4),(11,3),(12,3),(13,2),(15,2)]
CFG_RT  = [(6,14),(6,10),(7,8),(7,6),(8,5),(8,4),(9,3)]
CFG_GD  = [(3,300),(3,250),(4,140),(4,110),(4,80),(5,50),(5,40)]
for md,ms in CFG_DT:
    t = DecisionTreeClassifier(max_depth=md, min_samples_leaf=ms, random_state=0).fit(X[tr], yhard)
    fi = G.fidelity(yi, t.predict(X[te]), classes); fo = G.fidelity(yo, t.predict(X[ood]), classes)
    rows.append(dict(model="DT(hard)", md=md, ms=ms, rules=t.get_n_leaves(),
                     iid_posC=fi["pos_consistency"], ood_posC=fo["pos_consistency"],
                     iid_negR=fi["neg_credibility"], ood_negR=fo["neg_credibility"],
                     iid_agree=fi["agreement"], ood_agree=fo["agreement"]))
for md,ms in CFG_RT:
    M = G.MergedRT(classes, len(classes)).fit_roots(X[tr], P, md, ms)
    fi = G.fidelity(yi, M.predict(X[te]), classes); fo = G.fidelity(yo, M.predict(X[ood]), classes)
    rows.append(dict(model="RT(IID)", md=md, ms=ms, rules=M.n_rules(),
                     iid_posC=fi["pos_consistency"], ood_posC=fo["pos_consistency"],
                     iid_negR=fi["neg_credibility"], ood_negR=fo["neg_credibility"],
                     iid_agree=fi["agreement"], ood_agree=fo["agreement"]))
for md,ms in CFG_GD:
    M = G.gead(X[tr], P, classes, nn, md=md, ms=ms, N=4, sub_md=3,
               sub_ms=max(12, ms//5), lc_min_n=40, verbose=False)
    fi = G.fidelity(yi, M.predict(X[te]), classes); fo = G.fidelity(yo, M.predict(X[ood]), classes)
    rows.append(dict(model="RT(GEAD)", md=md, ms=ms, rules=M.n_rules(),
                     iid_posC=fi["pos_consistency"], ood_posC=fo["pos_consistency"],
                     iid_negR=fi["neg_credibility"], ood_negR=fo["neg_credibility"],
                     iid_agree=fi["agreement"], ood_agree=fo["agreement"]))
    print(rows[-1])
R = pd.DataFrame(rows)
R.to_csv(os.path.join(WORK,"gead","equal_budget.csv"), index=False, encoding="utf-8-sig")

print("\n--- full grid ---")
print(R.round(3).to_string(index=False))
print("\n--- nearest config to each budget ---")
for b in [100, 300, 1000]:
    print(f"\nbudget={b}")
    for m in ["DT(hard)","RT(IID)","RT(GEAD)"]:
        s = R[R.model==m].copy(); s["d"] = (np.log(s.rules)-np.log(b)).abs()
        r = s.nsmallest(1,"d").iloc[0]
        print(f"  {m:9s} rules={int(r.rules):5d} iid_posC={r.iid_posC:.3f} negR={r.iid_negR:.3f} "
              f"agree={r.iid_agree:.3f} | ood_posC={r.ood_posC:.3f} negR={r.ood_negR:.3f} agree={r.ood_agree:.3f}")
