# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "_work"))
import pandas as pd
from common import load
df = load(verbose=False)
print("=== application_confidence 取值分布 ===")
print(df.application_confidence.value_counts().to_string())
print("\n=== is_guessed 分布 ===")
print(df.application_is_guessed.value_counts().to_string())
print("\n=== confidence x is_guessed 交叉 ===")
print(pd.crosstab(df.application_confidence, df.application_is_guessed).to_string())
print("\n=== application_name 前 20，按是否有 SNI 拆 ===")
for flag, name in [(1, "有SNI"), (0, "无SNI")]:
    s = df[df.has_sni == flag].application_name.value_counts().head(10)
    print(f"  -- {name} --")
    print("   " + s.to_dict().__str__())
print("\n=== 'TLS.X' 形式的 App 名称有多少种、占多少流 ===")
sub = df[df.application_name.str.startswith("TLS.", na=False)]
print("种数:", sub.application_name.nunique(), " 流数:", len(sub),
      " 占比: %.1f%%" % (100*len(sub)/len(df)))
print("  其中 is_guessed=1 的比例: %.3f" % sub.application_is_guessed.mean())
print("\n=== 同一 App 的 application_name 种类数（看 DPI 是否稳定）===")
print(df.groupby("label").application_name.nunique().sort_values(ascending=False).to_string())
print("\n=== 几个典型 App 的最常见 DPI 名称 ===")
for a in ["whatsapp", "telegram", "reddit", "youtube"]:
    print(f"  {a}: ", df[df.label == a].application_name.value_counts().head(4).to_dict())
print("\n=== application_category_name 完整分布 ===")
print(df.application_category_name.value_counts().to_string())
