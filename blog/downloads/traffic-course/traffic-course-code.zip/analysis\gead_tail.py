# ---------------------------------------------------------------- rules
def _mask(X, conds):
    m = np.ones(len(X), bool)
    for f, thr, op in conds:
        m &= (X[:, f] <= thr) if op == "<=" else (X[:, f] > thr)
    return m

def _dedup_path(conds):
    seen, out = set(), []
    for f, thr, op in conds:
        if f in seen: continue
        seen.add(f); out.append((f, thr, op))
    return out

def _feat_kind(col):
    u = np.unique(col)
    if len(u) <= 2:                       return "bin"
    if np.allclose(u, np.round(u)):       return "int"
    return "cont"

def _norm(f, thr, op, X_ref):
    """Snap a split onto the feature's real domain (exact rewrite, no semantics change)."""
    col = X_ref[:, f]; kind = _feat_kind(col)
    if kind == "bin":
        return (">", 0.5) if op == ">" else ("<=", 0.5)
    if kind == "int":
        return (">=", float(np.ceil(thr))) if op == ">" else ("<=", float(np.floor(thr)))
    if abs(thr) < 1e-3 * (np.abs(col).max() + 1):
        return (">", 0.0) if op == ">" else ("<=", 0.0)
    return op, float(thr)

def _fmt(f, thr, op, names, X_ref, CN=None):
    CN = CN or {}
    nm = CN.get(names[f], names[f]); col = X_ref[:, f]; kind = _feat_kind(col)
    op2, thr2 = _norm(f, thr, op, X_ref)
    if kind == "bin":
        return f"{nm}={'1' if op2=='>' else '0'}"
    if kind == "int":
        return f"{nm} {op2} {int(thr2)}"
    q = int(round(100 * (col <= thr2).mean()))
    v = f"{thr2:.4g}"
    return f"{nm} {op2} {v} (p{q})"

def _fmt_en(f, thr, op, names, X_ref):
    nm = names[f]; col = X_ref[:, f]; kind = _feat_kind(col)
    op2, thr2 = _norm(f, thr, op, X_ref)
    if kind == "bin":   return f"{nm} {'==' if op2=='>' else '!='} {1 if op2=='>' else 0}"
    if kind == "int":   return f"{nm} {op2} {int(thr2)}"
    return f"{nm} {op2} {thr2:.4g}"

def _prune(X, conds, base_sup, conf_fn, tol=0.02):
    """Greedy condition removal: drop a condition while confidence barely drops."""
    keep = _dedup_path(conds)
    if not keep: return keep
    c0 = conf_fn(_mask(X, keep))
    for i in range(len(keep)-1, -1, -1):
        if len(keep) <= 1: break
        trial = keep[:i] + keep[i+1:]
        m = _mask(X, trial)
        if m.sum() < base_sup: continue
        if conf_fn(m) >= c0 - tol:
            keep = trial
    return keep

def _rule_row(c, conds, X_ref, y_pred_ref, y_true_ref, feat_names, CN,
              extra=None):
    m = _mask(X_ref, conds)
    sup = int(m.sum())
    conf = float((y_pred_ref[m] == c).mean()) if y_pred_ref is not None else np.nan
    prec = float((y_true_ref[m] == c).mean()) if y_true_ref is not None else np.nan
    en = " AND ".join(_fmt_en(f, t, o, feat_names, X_ref) for f, t, o in conds)
    cn = " 且 ".join(_fmt(f, t, o, feat_names, X_ref, CN) for f, t, o in conds)
    row = dict(cls=c, support=sup, confidence=round(conf,3), precision_true=round(prec,3),
               n_cond=len(conds), rule_en=f"IF {en} THEN {c}",
               rule_cn=f"若 {cn} 则判为 {c}",
               conds=[(feat_names[f], o, round(t,6)) for f,t,o in conds])
    if extra: row.update(extra)
    return row

def extract_rules(M, feat_names, X_ref, y_pred_ref, y_true_ref, classes,
                  CN=None, min_support=20, min_conf=0.55, top_k=5,
                  max_conds=5, prune_tol=0.02, verbose=False):
    """Walk merged-tree leaves -> rule candidates -> prune conditions -> keep best."""
    CN = CN or {}
    rows, seen = [], set()
    for c in classes:
        r = M.roots[c]; la = r.apply(X_ref)
        for lid in sorted(M.lc.get(c, set())):
            st = M.subs[c].get(lid)
            if st is None: continue
            mroot = la == lid
            if mroot.sum() < 8: continue
            sl = st.apply(X_ref[mroot])
            for slid in np.unique(sl):
                m = mroot.copy(); m[mroot] = (sl == slid)
                if m.sum() < min_support: continue
                conds = _dedup_path(leaf_path(r.tree_, lid) + leaf_path(st.tree_, int(slid)))
                conds = conds[:max_conds]
                if _mask(X_ref, conds).sum() < min_support: continue
                conf0 = float((y_pred_ref[_mask(X_ref, conds)] == c).mean())
                if conf0 < min_conf: continue
                conds = _prune(X_ref, conds, min_support,
                               lambda mm: float((y_pred_ref[mm] == c).mean()), prune_tol)
                row = _rule_row(c, conds, X_ref, y_pred_ref, y_true_ref, feat_names, CN)
                if row["rule_en"] in seen: continue
                seen.add(row["rule_en"]); rows.append(row)
    R = pd.DataFrame(rows)
    if len(R) == 0: return R
    R = R.sort_values(["cls","support","confidence"], ascending=[True,False,False])
    return R.groupby("cls").head(top_k).reset_index(drop=True)

def perclass_rules(M, feat_names, X_ref, classes, priors, CN=None,
                   min_support=30, max_conds=5, top_k=2, tau_mult=2.0):
    """Per-class high-probability regions (the paper's per-attack rule lists).
    Fires on the class's distilled probability, so rare classes stay describable."""
    CN = CN or {}
    P = M.predict_proba(X_ref)
    rows, seen = [], set()
    for j, c in enumerate(classes):
        r = M.roots[c]; la = r.apply(X_ref); p = P[:, j]
        tau = max(0.30, tau_mult * priors.get(c, 0.1))
        cands = []
        lcset = M.lc.get(c, set())
        for lid in np.unique(la):
            m = la == lid
            if m.sum() < 8: continue
            if lid in lcset and lid in M.subs[c]:
                st = M.subs[c][lid]; sl = st.apply(X_ref[m])
                for slid in np.unique(sl):
                    conds = _dedup_path(leaf_path(r.tree_, int(lid)) +
                                        leaf_path(st.tree_, int(slid)))[:max_conds]
                    mm = _mask(X_ref, conds)
                    if mm.sum() < min_support: continue
                    cands.append((int(mm.sum()), float(p[mm].mean()), conds))
            else:
                conds = _dedup_path(leaf_path(r.tree_, int(lid)))[:max_conds]
                mm = _mask(X_ref, conds)
                if mm.sum() < min_support: continue
                cands.append((int(mm.sum()), float(p[mm].mean()), conds))
        cands.sort(key=lambda t: (-(t[0]*t[1])))
        kept = 0
        for sup, mp, conds in cands:
            if kept >= top_k: break
            if mp < tau: continue
            row = _rule_row(c, conds, X_ref, None, None, feat_names, CN,
                            extra=dict(mean_prob=round(mp,3), prior=round(priors.get(c,0),3),
                                       lift=round(mp/max(priors.get(c,1e-9),1e-9),2)))
            row["rule_cn"] = row["rule_cn"].replace("则判为", "则")
            if row["rule_en"] in seen: continue
            seen.add(row["rule_en"]); rows.append(row); kept += 1
    R = pd.DataFrame(rows)
    if len(R)==0: return R
    R = R.drop(columns=["confidence","precision_true"])
    return R.reset_index(drop=True)

# ---------------------------------------------------------------- fidelity
def fidelity(y_model, y_tree, labels):
    """Multi-class analogue of the paper's Positive Consistency / Negative Credibility."""
    pos, neg = [], []
    for c in labels:
        mc = y_model == c; tc = y_tree == c
        if mc.sum(): pos.append(float((y_tree[mc] == c).mean()))
        if tc.sum(): neg.append(float((y_model[tc] == c).mean()))
    return dict(pos_consistency=float(np.mean(pos)),
                neg_credibility=float(np.mean(neg)),
                agreement=float((y_model == y_tree).mean()))
