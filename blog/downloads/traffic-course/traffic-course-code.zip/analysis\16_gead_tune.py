# -*- coding: utf-8 -*-
"""GEAD hyper-parameter check (paper does a grid search on alpha_O/alpha_E/Md/Ms;
we additionally check the augmentation mix)."""
import os, sys, warnings, itertools, json
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np, pandas as pd
from common import *
import gead as G
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier

RULE_FEATS = ["dur_ms","pkt","byt","dn_ratio","dn_pkt_ratio","bytes_per_pkt","pps","bps",
              "ps_mean","ps_std","ps_max","piat_mean","piat_std",
              "is_udp","syn_ratio","psh_ratio","rst_cnt","fin_cnt",
              "dst_port","has_sni","has_ja4"]
df = load()
d = df[((~df.is_lan_bg) & (df.dst_port != 53))].reset_index(drop=True)
X = d[RULE_FEATS].replace([np.inf,-np.inf], np.nan).fillna(0).values.astype(np.float64)
y = d.label.values; day = d.capture_day.values
rng = np.random.default_rng(0)
iid_idx = np.where(day!="day5")[0]; rng.shuffle(iid_idx)
cut=int(0.75*len(iid_idx)); tr, te = iid_idx[:cut], iid_idx[cut:]
ood = np.where(day=="day5")[0]
mlp = make_pipeline(StandardScaler(), MLPClassifier(hidden_layer_sizes=(256,128,64),
        max_iter=600, early_stopping=True, n_iter_no_change=20, random_state=0)).fit(X[tr], y[tr])
nn = G.NNFunc(mlp, mlp.classes_); classes=list(mlp.classes_)
P = nn.forward(X[tr]); Pi = nn.forward(X[te]); Po = nn.forward(X[ood])
yi = np.array(classes)[Pi.argmax(1)]; yo = np.array(classes)[Po.argmax(1)]

rows=[]
for ood_frac, N, sub_ms in itertools.product([0.0,0.25,0.5],[4,10],[20]):
    M = G.gead(X[tr], P, classes, nn, md=4, ms=80, N=N, sub_md=3, sub_ms=sub_ms,
               ood_frac=ood_frac, verbose=False)
    fi = G.fidelity(yi, M.predict(X[te]), classes)
    fo = G.fidelity(yo, M.predict(X[ood]), classes)
    rows.append(dict(ood_frac=ood_frac, N=N, sub_ms=sub_ms, rules=M.n_rules(),
                     iid_posC=round(fi["pos_consistency"],4), iid_negR=round(fi["neg_credibility"],4),
                     iid_agree=round(fi["agreement"],4),
                     ood_posC=round(fo["pos_consistency"],4), ood_negR=round(fo["neg_credibility"],4),
                     ood_agree=round(fo["agreement"],4)))
    print(rows[-1])
R = pd.DataFrame(rows)
R.to_csv(os.path.join(WORK,"gead","tuning.csv"), index=False, encoding="utf-8-sig")
print("\nbest by iid agreement:\n", R.sort_values("iid_agree",ascending=False).head(3).to_string(index=False))
print("\nbest by ood agreement:\n", R.sort_values("ood_agree",ascending=False).head(3).to_string(index=False))
