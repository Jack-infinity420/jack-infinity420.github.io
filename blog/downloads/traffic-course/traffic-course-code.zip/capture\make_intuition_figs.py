﻿# -*- coding: utf-8 -*-
"""Draw 'intuition' figures from the user's own dataset + print anchor statistics."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "_work"))
import numpy as np, pandas as pd
from common import load, APPS, WORK

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm

FONT = r"C:\Windows\Fonts\msyh.ttc"
fm.fontManager.addfont(FONT)
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "img")
os.makedirs(OUT, exist_ok=True)

df = load(verbose=False)
print("flows:", len(df))

# ------------------------------------------------------------------ Fig A: 包长谱
fig, ax = plt.subplots(1, 2, figsize=(12, 4.2), dpi=150)
bins = np.arange(40, 1560, 8)
ax[0].hist(df.bidirectional_min_ps.clip(0, 1550), bins=bins, log=True,
           color="#4C78A8", label="每条流的最小包长 min_ps")
ax[0].hist(df.bidirectional_max_ps.clip(0, 1550), bins=bins, log=True,
           color="#F58518", alpha=.6, label="每条流的最大包长 max_ps")
for x, txt in [(60, "60B 纯ACK\n(补足最小帧)"), (74, "74B SYN"), (1514, "1514B\nMTU 满载")]:
    ax[0].axvline(x, color="crimson", ls=":", lw=1)
    ax[0].text(x, ax[0].get_ylim()[1]*.55, txt, fontsize=7.5, color="crimson",
               ha="center", va="top")
ax[0].set_xlabel("包长（字节，含以太网头）"); ax[0].set_ylabel("流数（对数）")
ax[0].set_title("① 网络里的包长不是连续的：几个固定档位")
ax[0].legend(fontsize=8); ax[0].grid(alpha=.25, axis="y")

sub = df[df.bidirectional_max_ps <= 1600]
ax[1].hist(sub.bidirectional_max_ps, bins=np.arange(40, 1560, 2), log=True,
           color="#54A24B")
ax[1].set_xlim(1400, 1530)
ax[1].set_xlabel("max_ps（放大 1400–1530）"); ax[1].set_ylabel("流数（对数）")
ax[1].set_title("② 放大看：大量流的最大包恰好停在 1514 / 1497")
ax[1].grid(alpha=.25, axis="y")
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig5_包长谱.png")); plt.close(fig)

# ------------------------------------------------------------------ Fig B: 流长/时长
fig, ax = plt.subplots(1, 2, figsize=(12, 4.2), dpi=150)
p = df.bidirectional_packets.clip(lower=1)
ax[0].hist(p, bins=np.logspace(0, 6, 60), color="#4C78A8", log=True)
ax[0].set_xscale("log"); ax[0].set_xlabel("每条流的包数（对数）"); ax[0].set_ylabel("流数（对数）")
ax[0].set_title(f"③ 流长极重尾：中位数 {int(p.median())} 包，p99={int(p.quantile(.99))}，最大 {int(p.max()):,}")
ax[0].axvline(p.median(), color="crimson", ls="--", lw=1)
ax[0].grid(alpha=.25)

d = df.bidirectional_duration_ms.clip(lower=1)
ax[1].hist(d, bins=np.logspace(0, 6.4, 60), color="#F58518", log=True)
ax[1].set_xscale("log"); ax[1].set_xlabel("流持续时长 ms（对数）"); ax[1].set_ylabel("流数（对数）")
ax[1].set_title(f"④ 时长跨度 6 个数量级：中位 {int(d.median())} ms，p99={int(d.quantile(.99)):,} ms")
ax[1].grid(alpha=.25)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig6_流长与时长.png")); plt.close(fig)

# ------------------------------------------------------------------ Fig C: 各 App 体量
d_app = df[(~df.is_lan_bg) & (df.dst_port != 53)]
fig, ax = plt.subplots(1, 3, figsize=(13, 4.2), dpi=150)
order = d_app.groupby("label").bidirectional_bytes.median().sort_values().index
data = [np.log10(d_app[d_app.label == a].bidirectional_bytes.clip(lower=1)) for a in order]
ax[0].boxplot(data, orientation="horizontal", tick_labels=order, showfliers=False)
ax[0].set_xlabel("log10(流字节数)"); ax[0].set_title("⑤ 体量：YouTube/TikTok 的流更大")

data = [np.log10(d_app[d_app.label == a].bidirectional_packets.clip(lower=1)) for a in order]
ax[1].boxplot(data, orientation="horizontal", tick_labels=order, showfliers=False)
ax[1].set_xlabel("log10(流包数)"); ax[1].set_title("⑥ 包数：Reddit/WhatsApp 更高")

data = [d_app[d_app.label == a].dn_ratio.clip(0, 1) for a in order]
ax[2].boxplot(data, orientation="horizontal", tick_labels=order, showfliers=False)
ax[2].set_xlabel("下行字节占比 dn_ratio"); ax[2].set_title("⑦ 方向性：下载 vs 交互")
ax[2].axvline(0.5, color="grey", ls=":")
for a in ax[1:]:
    a.tick_params(labelsize=7)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig7_各App体量与方向.png")); plt.close(fig)

# ------------------------------------------------------------------ Fig D: 端口
fig, ax = plt.subplots(1, 2, figsize=(12, 4.2), dpi=150)
top = df.dst_port.value_counts().head(12)[::-1]
colors = ["#E45756" if p in {1900, 5353, 5355, 3702, 137, 138, 67, 68} else
          ("#F58518" if p == 53 else "#4C78A8") for p in top.index]
ax[0].barh([str(i) for i in top.index], top.values, color=colors)
ax[0].set_xlabel("流数"); ax[0].set_ylabel("目的端口")
ax[0].set_title("⑧ 端口分布：红=局域网背景，橙=公网DNS，蓝=真正的应用端口")
ax[0].grid(alpha=.25, axis="x")

# 443 上每个 App 占多少 -> 端口无法分开 App
c = pd.crosstab(df[df.dst_port == 443].label, "x")
share = (c["x"] / c["x"].sum()).sort_values(ascending=False)
ax[1].bar(share.index, share.values, color="#4C78A8")
ax[1].set_ylabel("占 443 端口流的比例"); ax[1].tick_params(axis="x", rotation=45, labelsize=8)
ax[1].set_title("⑨ 443 端口上 10 个 App 全都在：端口不能区分应用")
ax[1].grid(alpha=.25, axis="y")
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig8_端口与现实.png")); plt.close(fig)

# ------------------------------------------------------------------ anchor stats
print("\n===== 供教材引用的锚点数字 =====")
q = lambda s: dict(n=len(s), med=float(s.median()), p10=float(s.quantile(.1)),
                   p90=float(s.quantile(.9)), p99=float(s.quantile(.99)), mx=float(s.max()))
print("最小包长 min_ps :", q(df.bidirectional_min_ps))
print("最大包长 max_ps :", q(df.bidirectional_max_ps))
print("包数 packets    :", q(df.bidirectional_packets))
print("字节数 bytes    :", q(df.bidirectional_bytes))
print("时长 duration_ms:", q(df.bidirectional_duration_ms))
print("包间隔均值 piat :", q(df.bidirectional_mean_piat_ms))
n_eq = lambda v, x: int((df[v] == x).sum())
for v, x in [("bidirectional_min_ps", 54), ("bidirectional_min_ps", 60),
             ("bidirectional_max_ps", 1514), ("bidirectional_packets", 1),
             ("bidirectional_packets", 2), ("bidirectional_packets", 4)]:
    print(f"  {v} == {x}: {n_eq(v,x)} 条 ({n_eq(v,x)/len(df)*100:.1f}%)")
print("\n每 App 流的中位包数/字节/时长/dn_ratio:")
print(d_app.groupby("label")[["bidirectional_packets", "bidirectional_bytes",
                              "bidirectional_duration_ms", "dn_ratio", "rst_cnt"]]
      .median().round(2).to_string())
print("\nRST>0 的流占比：", round((df.bidirectional_rst_packets > 0).mean(), 4))
print("PSH>0 的流占比：", round((df.bidirectional_psh_packets > 0).mean(), 4))
print("纯 ACK 流(min=max=54)占比：", round(((df.bidirectional_min_ps == 54) &
      (df.bidirectional_max_ps == 54)).mean(), 4))
print("\nsaved figures to", OUT)
