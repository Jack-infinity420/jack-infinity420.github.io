# -*- coding: utf-8 -*-
import os, ipaddress
import pandas as pd, numpy as np
pd.set_option("display.width", 250)

BASE = r"D:\流量分析实战\261112\Encrypted_Mobile_Social_Media"
APPS = ["facebook","instagram","linkedin","reddit","snapchat","telegram","tiktok","twitter","whatsapp","youtube"]
df = pd.concat([pd.read_csv(os.path.join(BASE,a+".csv"), low_memory=False).assign(_file=a) for a in APPS], ignore_index=True)

def is_public(ip):
    try:
        a = ipaddress.ip_address(str(ip))
        return a.is_global
    except Exception:
        return False

df["dst_public"] = df.dst_ip.map(is_public)
LAN_PORTS = {1900,5353,5355,3702,67,68,137,138,139,5350,8610,8612,1900,57621,17500,52217}
df["dst_port_lan"] = df.dst_port.isin(LAN_PORTS)
df["is_lan_bg"] = (~df.dst_public) | df.dst_port_lan

print("=== LAN / background share ===")
print(df.is_lan_bg.value_counts(normalize=True).to_string())
print()
print(pd.crosstab(df._file, df.is_lan_bg, normalize="index").round(3).to_string())

print("\n=== app-attributable (public dst, not LAN port) per app ===")
sub = df[~df.is_lan_bg]
print(sub._file.value_counts().to_string())
print("\nremaining rows:", len(sub), " (%.1f%%)" % (100*len(sub)/len(df)))

print("\n=== within app-attributable: dst_port top 12 ===")
print(sub.dst_port.value_counts().head(12).to_string())

print("\n=== within app-attributable: category ===")
print(sub.application_category_name.value_counts().head(15).to_string())

print("\n=== per-app: share of TLS/QUIC vs plaintext ===")
print(pd.crosstab(sub._file, sub.protocol).to_string())

print("\n=== SNI purity inside app-attributable subset (top 25 by count) ===")
s = sub[sub.requested_server_name.notna()]
g = s.groupby("requested_server_name")["Label"].agg(cnt="size", purity=lambda x: x.value_counts(normalize=True).iloc[0])
g = g.sort_values("cnt", ascending=False).head(25)
print(g.round(3).to_string())
print("weighted purity in subset: %.4f" % ((s.groupby('requested_server_name')['Label']
      .apply(lambda x: x.value_counts(normalize=True).iloc[0]) * s.groupby('requested_server_name').size()).sum()/len(s)))

print("\n=== device/session structure: (capture_file,src_mac) groups ===")
grp = df.groupby(["capture_file"]).agg(nflows=("id","size"), n_src_ip=("src_ip","nunique"), n_src_mac=("src_mac","nunique"))
print(grp.describe().round(2).to_string())

print("\n=== JA4 within app-attributable ===")
c = sub[sub.client_fingerprint.notna()]
print("rows with JA4:", len(c), "of", len(sub))
gg = c.groupby("client_fingerprint")["Label"].agg(cnt="size", nu="nunique", purity=lambda x: x.value_counts(normalize=True).iloc[0])
print(gg.sort_values("cnt",ascending=False).head(12).round(3).to_string())
print("weighted purity: %.4f" % ((gg.purity*gg.cnt).sum()/gg.cnt.sum()))
