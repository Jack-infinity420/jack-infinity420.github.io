# -*- coding: utf-8 -*-
"""Stage A: feature-view ablation (feature categories = the paper's 4 basis families)."""
import os, sys, json, time, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np, pandas as pd
from common import *

RES = os.path.join(WORK, "results_A_views.csv")
df = load()
print(df.groupby("label").size().to_string())

from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import accuracy_score, f1_score

SUBSETS = {
    "ALL":      np.ones(len(df), bool),
    "APP":      (~df.is_lan_bg).values,
    "APP_NDNS": ((~df.is_lan_bg) & (df.dst_port != 53)).values,
}

def run(X, y, groups_tag, subset_tag, view_tag, model):
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    t0=time.time()
    pred = cross_val_predict(model, X, y, cv=cv, n_jobs=1)
    m = metrics(y, pred)
    m.update(dict(subset=subset_tag, view=view_tag, model=model.__class__.__name__,
                  n=len(y), n_feat=X.shape[1], sec=round(time.time()-t0,1)))
    print(f"  {subset_tag:9s} {view_tag:14s} {m['model']:6s} acc={m['acc']:.4f} f1={m['macro_f1']:.4f} bal={m['bal_acc']:.4f} n={m['n']} d={m['n_feat']}")
    return m

rows=[]
for sub_name, mask in SUBSETS.items():
    d = df[mask].reset_index(drop=True)
    y = d["label"].values
    print(f"\n=== subset {sub_name}: {len(d)} rows ===")
    print(d.label.value_counts().to_string())
    for vname, cols in VIEWS.items():
        cols = [c for c in cols if c in d.columns]
        X, names, _ = build_matrix(d, cols)
        Xn = X.values
        for model in [HistGradientBoostingClassifier(max_iter=300, learning_rate=0.08,
                                                     max_leaf_nodes=31, random_state=0),
                      RandomForestClassifier(n_estimators=300, n_jobs=-1, random_state=0)]:
            rows.append(run(Xn, y, None, sub_name, vname, model))

res = pd.DataFrame(rows)
res.to_csv(RES, index=False, encoding="utf-8-sig")
print("\n", res.pivot_table(index="view", columns=["subset","model"], values="acc").round(4).to_string())
print("\n", res.pivot_table(index="view", columns=["subset","model"], values="macro_f1").round(4).to_string())
